
Muna Mohamud -  402600337
Module: Web Technology 512

Application overview -

Richfield Connect is a browser-only React Single-Page Application for Richfield students. It allows a student register a profile,login into their profile, view a live profile preview, create posts, like posts and delete them as well as keeping profile and post data in browser localStorage.

Component architecture -

`App.jsx` is the root component and is the file you run the program through(open the terminal and type npm run dev). It wraps the interface with `AppProvider` and defines the React Router routes.
`AppContext.jsx` provides global user and post state through the Context API and `useReducer`.
`Navbar`, `Footer`, `Home`, `About`, `SignUpForm`, `ProfilePreview`, `Profile`, `Feed`, `CreatePost`, and `Post` each handle a focused part of the interface.Along with this, each file has a css file that styles it.

Run the project locally -

Firstly, install Node.js 18. Open a terminal in the project folder in the file App.jsx. Run `npm install` and then run `npm run dev`. Open the local URL printed by Vite in a browser.

To create a production build, run `npm run build`.

Technologies used -

 React 18
 React Router DOM v6
 Vite
 Browser localStorage
 Plain CSS with responsive media queries and CSS transitions/animations

External resources - 

 React documentation: https://react.dev/
 React Router documentation: https://reactrouter.com/
 Vite documentation: https://vite.dev/

The project includes the local image - `src/richfield-kids.jpg`. 
