import React, { createContext, useContext, useReducer, useEffect } from 'react'

// ===== Initial State =====
const initialState = {
  user: null,
  posts: [],
}

// ===== Load from localStorage =====
const loadState = () => {
  try {
    const savedUser = localStorage.getItem('richfield_user')
    const savedPosts = localStorage.getItem('richfield_posts')

    return {
      user: savedUser ? JSON.parse(savedUser) : null,
      posts: savedPosts ? JSON.parse(savedPosts) : [],
    }
  } catch {
    return initialState
  }
}

// ===== Actions =====
const ACTIONS = {
  HYDRATE_STATE: 'HYDRATE_STATE',
  REGISTER_USER: 'REGISTER_USER',
  LOGIN_USER: 'LOGIN_USER',
  LOGOUT_USER: 'LOGOUT_USER',
  ADD_POST: 'ADD_POST',
  TOGGLE_LIKE: 'TOGGLE_LIKE',
  DELETE_POST: 'DELETE_POST',
}

// ===== Reducer =====
function appReducer(state, action) {
  switch (action.type) {
    case ACTIONS.HYDRATE_STATE:
      return action.payload

    case ACTIONS.REGISTER_USER:
      return { ...state, user: action.payload }

    case ACTIONS.LOGIN_USER:
      return { ...state, user: action.payload }

    case ACTIONS.LOGOUT_USER:
      return { ...state, user: null }

    case ACTIONS.ADD_POST:
      return { ...state, posts: [action.payload, ...state.posts] }

    case ACTIONS.TOGGLE_LIKE: {
      const { postId } = action.payload
      return {
        ...state,
        posts: state.posts.map(post =>
          post.id === postId
            ? {
                ...post,
                likes: post.liked ? post.likes - 1 : post.likes + 1,
                liked: !post.liked,
              }
            : post
        ),
      }
    }

    case ACTIONS.DELETE_POST:
      return {
        ...state,
        posts: state.posts.filter(post => post.id !== action.payload),
      }

    default:
      return state
  }
}

// ===== Context =====
const AppContext = createContext(null)

// ===== Provider =====
export function AppProvider({ children }) {
  const [state, dispatch] = useReducer(appReducer, initialState)
  const [isHydrated, setIsHydrated] = React.useState(false)

  // Restore saved browser data once when the provider mounts.
  useEffect(() => {
    dispatch({ type: ACTIONS.HYDRATE_STATE, payload: loadState() })
    setIsHydrated(true)
  }, [])

  // Persist to localStorage when state changes
  useEffect(() => {
    // Does not overwrite saved data with the empty initial state before hydration.
    if (!isHydrated) return

    if (state.user) {
      localStorage.setItem('richfield_user', JSON.stringify(state.user))
    } else {
      localStorage.removeItem('richfield_user')
    }
    localStorage.setItem('richfield_posts', JSON.stringify(state.posts))
  }, [state.user, state.posts, isHydrated])

  // ===== Register User (Sign Up) =====
  const registerUser = (userData) => {
    // Save user account under their username so they can log in later
    const accounts = JSON.parse(localStorage.getItem('richfield_accounts') || '{}')
    accounts[userData.username] = {
      ...userData,
      password: userData.password, // stored here only for demo
    }
    localStorage.setItem('richfield_accounts', JSON.stringify(accounts))

    // Log them in
    const { password, ...safeUser } = userData
    dispatch({ type: ACTIONS.REGISTER_USER, payload: safeUser })
  }

  // ===== Login User =====
  const loginUser = (username, password) => {
    const accounts = JSON.parse(localStorage.getItem('richfield_accounts') || '{}')
    const account = accounts[username]

    if (!account) {
      return { success: false, message: 'User not found. Please sign up first.' }
    }

    if (account.password !== password) {
      return { success: false, message: 'Incorrect password. Please try again.' }
    }

    const { password: _pw, ...safeUser } = account
    dispatch({ type: ACTIONS.LOGIN_USER, payload: safeUser })
    return { success: true }
  }

  // ===== Logout User =====
  const logoutUser = () => {
    dispatch({ type: ACTIONS.LOGOUT_USER })
  }

  // ===== Posts =====
  const addPost = (post) => dispatch({ type: ACTIONS.ADD_POST, payload: post })
  const toggleLike = (postId) =>
    dispatch({ type: ACTIONS.TOGGLE_LIKE, payload: { postId } })
  const deletePost = (postId) =>
    dispatch({ type: ACTIONS.DELETE_POST, payload: postId })

  const value = {
    user: state.user,
    posts: state.posts,
    registerUser,
    loginUser,
    logoutUser,
    addPost,
    toggleLike,
    deletePost,
  }

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>
}

// ===== Custom hook =====
export function useAppContext() {
  const context = useContext(AppContext)
  if (!context) {
    throw new Error('useAppContext must be used within an AppProvider')
  }
  return context
}
