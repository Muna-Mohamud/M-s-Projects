import React, { useState } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import { useAppContext } from '../context/AppContext'
import './Login.css'

function Login() {
  const navigate = useNavigate()
  const { loginUser } = useAppContext()

  const [formData, setFormData] = useState({
    username: '',
    password: '',
  })

  const [errors, setErrors] = useState({})
  const [touched, setTouched] = useState({})

  // ===== handles the input Change =====
  const handleChange = (e) => {
    const { name, value } = e.target
    setFormData(prev => ({ ...prev, [name]: value }))
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: '' }))
    }
  }

  // ===== Handle Blur =====
  const handleBlur = (e) => {
    const { name } = e.target
    setTouched(prev => ({ ...prev, [name]: true }))
    validateField(name)
  }

  // ===== Validates the single field =====
  const validateField = (fieldName) => {
    let error = ''
    if (fieldName === 'username' && !formData.username.trim()) {
      error = 'Username is required'
    }
    if (fieldName === 'password' && !formData.password) {
      error = 'Password is required'
    }
    setErrors(prev => ({ ...prev, [fieldName]: error }))
    return error === ''
  }

  // ===== handles the submit =====
  const handleSubmit = (e) => {
    e.preventDefault()

    const usernameValid = validateField('username')
    const passwordValid = validateField('password')
    setTouched({ username: true, password: true })

    if (!usernameValid || !passwordValid) return

    const result = loginUser(formData.username.trim(), formData.password)

    if (result.success) {
      navigate('/profile')
    } else {
      setErrors({ password: result.message })
    }
  }

  return (
    <div className="login-page">
      <div className="login-card">
        <div className="login-header">
          <div className="login-logo">●</div>
          <h2>Welcome Back</h2>
          <p className="login-subtitle">Sign in to Richfield Connect</p>
        </div>

        <form onSubmit={handleSubmit} className="login-form" noValidate>
          {/* handling the username */}
          <div className="form-group">
            <label htmlFor="username">Username</label>
            <input
              type="text"
              id="username"
              name="username"
              value={formData.username}
              onChange={handleChange}
              onBlur={handleBlur}
              placeholder="Enter your username"
              className={errors.username && touched.username ? 'error-input' : ''}
            />
            {errors.username && touched.username && (
              <span className="field-error">{errors.username}</span>
            )}
          </div>

          {/* handling the password */}
          <div className="form-group">
            <label htmlFor="password">Password</label>
            <input
              type="password"
              id="password"
              name="password"
              value={formData.password}
              onChange={handleChange}
              onBlur={handleBlur}
              placeholder="Enter your password"
              className={errors.password && touched.password ? 'error-input' : ''}
            />
            {errors.password && touched.password && (
              <span className="field-error">{errors.password}</span>
            )}
          </div>

          <button type="submit" className="login-btn">
            Login
          </button>
        </form>

        <p className="login-footer">
          Don't have an account? <Link to="/signup">Sign up here</Link>
        </p>
      </div>
    </div>
  )
}

export default Login