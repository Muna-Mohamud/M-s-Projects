import React, { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAppContext } from '../context/AppContext'
import ProfilePreview from './ProfilePreview'
import './SignUpForm.css'

function SignUpForm() {
  const navigate = useNavigate()
  const { registerUser, user } = useAppContext()

  // Redirect if user is already logged in
  useEffect(() => {
    if (user) {
      navigate('/profile')
    }
  }, [user, navigate])

  // ===== Form state =====
  const [formData, setFormData] = useState({
    name: '',
    username: '',
    studentNumber: '',
    campus: '',
    email: '',
    password: '',
    confirmPassword: '',
    interests: [],
    bio: '',
    termsAccepted: false,
  })

  const [errors, setErrors] = useState({})
  const [touched, setTouched] = useState({})
  const [submitAttempted, setSubmitAttempted] = useState(false)

  // ===== Interest options =====
  const interestOptions = [
    'Programming',
    'Design',
    'Data Science',
    'Networking',
    'Cybersecurity',
  ]

  // ===== Handles input change =====
  const handleChange = (e) => {
    const { name, value, type, checked } = e.target

    if (type === 'checkbox' && name === 'interests') {
      setFormData(prev => {
        const currentInterests = prev.interests
        const updated = checked
          ? [...currentInterests, value]
          : currentInterests.filter(i => i !== value)
        return { ...prev, interests: updated }
      })
    } else if (type === 'checkbox') {
      setFormData(prev => ({ ...prev, [name]: checked }))
    } else {
      setFormData(prev => ({ ...prev, [name]: value }))
    }

    // Clear error for this field when user types
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: '' }))
    }
  }

  // ===== Handle blur =====
  const handleBlur = (e) => {
    const { name } = e.target
    setTouched(prev => ({ ...prev, [name]: true }))
    validateField(name)
  }

  // ===== Validates single field =====
  const validateField = (fieldName) => {
    const value = formData[fieldName]
    let error = ''

    switch (fieldName) {
      case 'name':
        if (!value || value.trim() === '') error = 'Full name is required'
        break

      case 'username':
        if (!value || value.trim() === '') error = 'Username is required'
        break

      case 'studentNumber':
        if (!value || value.trim() === '') {
          error = 'Student number is required'
        } else if (!/^\d{6,}$/.test(value)) {
          error = 'Must be at least 6 numeric digits'
        }
        break

      case 'campus':
        if (!value || value === '') error = 'Please select a campus'
        break

      case 'email':
        if (!value || value.trim() === '') {
          error = 'Email is required'
        } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) {
          error = 'Please enter a valid email address'
        }
        break

      case 'password':
        if (!value) {
          error = 'Password is required'
        } else if (value.length < 8) {
          error = 'Password must be at least 8 characters'
        }
        break

      case 'confirmPassword':
        if (!value) {
          error = 'Please confirm your password'
        } else if (value !== formData.password) {
          error = 'Passwords do not match'
        }
        break

      case 'interests':
        if (formData.interests.length === 0) {
          error = 'Select at least one interest'
        }
        break

      case 'bio':
        if (!value || value.trim() === '') {
          error = 'Bio is required'
        } else if (value.trim().length < 20) {
          error = 'Bio must be at least 20 characters'
        }
        break

      case 'termsAccepted':
        if (!formData.termsAccepted) {
          error = 'You must accept the terms and conditions'
        }
        break
    }

    setErrors(prev => ({ ...prev, [fieldName]: error }))
    return error === ''
  }

  // ===== Validates all fields =====
  const validateAll = () => {
    const fields = [
      'name', 'username', 'studentNumber', 'campus', 'email',
      'password', 'confirmPassword', 'interests', 'bio', 'termsAccepted'
    ]
    let isValid = true
    fields.forEach(field => {
      if (!validateField(field)) isValid = false
    })
    return isValid
  }

  // ===== Handles submit =====
  const handleSubmit = (e) => {
    e.preventDefault()
    setSubmitAttempted(true)

    if (!validateAll()) {
      // Set all fields as touched to show errors
      const allTouched = {}
      Object.keys(formData).forEach(key => {
        allTouched[key] = true
      })
      setTouched(allTouched)
      return
    }

    // Registration data
    const userData = {
      name: formData.name.trim(),
      username: formData.username.trim(),
      studentNumber: formData.studentNumber.trim(),
      campus: formData.campus,
      email: formData.email.trim(),
      interests: formData.interests,
      bio: formData.bio.trim(),
      password: formData.password, // Store password for login
    }

    // Save to context and localStorage
    registerUser(userData)

    // Navigate to profile
    navigate('/profile')
  }

  // ===== Render =====
  return (
    <div className="signup-page">
      <div className="signup-container">
        <div className="signup-form-wrapper">
          <h2>Create Your Profile</h2>
          <p className="signup-subtitle">Join the Richfield Connect community</p>

          <form onSubmit={handleSubmit} className="signup-form" noValidate>
            {/* Name */}
            <div className="form-group">
              <label htmlFor="name">Full Name *</label>
              <input
                type="text"
                id="name"
                name="name"
                value={formData.name}
                onChange={handleChange}
                onBlur={handleBlur}
                placeholder="Enter your full name"
                className={errors.name && touched.name ? 'error-input' : ''}
              />
              {errors.name && touched.name && (
                <span className="field-error">{errors.name}</span>
              )}
            </div>

            {/* Username */}
            <div className="form-group">
              <label htmlFor="username">Username *</label>
              <input
                type="text"
                id="username"
                name="username"
                value={formData.username}
                onChange={handleChange}
                onBlur={handleBlur}
                placeholder="Choose a username"
                className={errors.username && touched.username ? 'error-input' : ''}
              />
              {errors.username && touched.username && (
                <span className="field-error">{errors.username}</span>
              )}
            </div>

            {/* Student number */}
            <div className="form-group">
              <label htmlFor="studentNumber">Student Number *</label>
              <input
                type="text"
                id="studentNumber"
                name="studentNumber"
                value={formData.studentNumber}
                onChange={handleChange}
                onBlur={handleBlur}
                placeholder="Enter your student number"
                className={errors.studentNumber && touched.studentNumber ? 'error-input' : ''}
              />
              {errors.studentNumber && touched.studentNumber && (
                <span className="field-error">{errors.studentNumber}</span>
              )}
            </div>

            {/* Campus */}
            <div className="form-group">
              <label htmlFor="campus">Campus *</label>
              <select
                id="campus"
                name="campus"
                value={formData.campus}
                onChange={handleChange}
                onBlur={handleBlur}
                className={errors.campus && touched.campus ? 'error-input' : ''}
              >
                <option value="">Select your campus</option>
                <option value="Bryanston Campus">Bryanston Campus (Johannesburg)</option>
                <option value="Newtown Junction Campus">Newtown Junction Campus (Johannesburg)</option>
                <option value="Pretoria Campus">Pretoria Campus</option>
                <option value="Cape Town Campus">Cape Town Campus</option>
                <option value="Centurion Campus">Centurion Campus</option>
                <option value="Musgrave Campus">Musgrave Campus</option>
                <option value="Umhlanga Campus">Umhlanga Campus</option>
                <option value="Polokwane Campus">Polokwane Campus</option>
                <option value="Online Campus">Online Campus</option>
              </select>
              {errors.campus && touched.campus && (
                <span className="field-error">{errors.campus}</span>
              )}
            </div>

            {/* Email */}
            <div className="form-group">
              <label htmlFor="email">Email Address *</label>
              <input
                type="email"
                id="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                onBlur={handleBlur}
                placeholder="Enter your email"
                className={errors.email && touched.email ? 'error-input' : ''}
              />
              {errors.email && touched.email && (
                <span className="field-error">{errors.email}</span>
              )}
            </div>

            {/* Password */}
            <div className="form-group">
              <label htmlFor="password">Password *</label>
              <input
                type="password"
                id="password"
                name="password"
                value={formData.password}
                onChange={handleChange}
                onBlur={handleBlur}
                placeholder="Min 8 characters"
                className={errors.password && touched.password ? 'error-input' : ''}
              />
              {errors.password && touched.password && (
                <span className="field-error">{errors.password}</span>
              )}
            </div>

            {/* Confirm password */}
            <div className="form-group">
              <label htmlFor="confirmPassword">Confirm Password *</label>
              <input
                type="password"
                id="confirmPassword"
                name="confirmPassword"
                value={formData.confirmPassword}
                onChange={handleChange}
                onBlur={handleBlur}
                placeholder="Re-enter your password"
                className={errors.confirmPassword && touched.confirmPassword ? 'error-input' : ''}
              />
              {errors.confirmPassword && touched.confirmPassword && (
                <span className="field-error">{errors.confirmPassword}</span>
              )}
            </div>

            {/* Interests */}
            <div className="form-group">
              <label>Interests * (select at least one)</label>
              <div className="interests-group">
                {interestOptions.map(interest => (
                  <label key={interest} className="interest-checkbox">
                    <input
                      type="checkbox"
                      name="interests"
                      value={interest}
                      checked={formData.interests.includes(interest)}
                      onChange={handleChange}
                    />
                    {interest}
                  </label>
                ))}
              </div>
              {errors.interests && touched.interests && (
                <span className="field-error">{errors.interests}</span>
              )}
            </div>

            {/* Bio */}
            <div className="form-group">
              <label htmlFor="bio">Short Bio *</label>
              <textarea
                id="bio"
                name="bio"
                value={formData.bio}
                onChange={handleChange}
                onBlur={handleBlur}
                placeholder="Tell us about yourself (min 20 characters)"
                rows="3"
                className={errors.bio && touched.bio ? 'error-input' : ''}
              />
              <span className="char-count">
                {formData.bio.length} / 20+ characters
              </span>
              {errors.bio && touched.bio && (
                <span className="field-error">{errors.bio}</span>
              )}
            </div>

            {/* Terms */}
            <div className="form-group terms-group">
              <label className="terms-label">
                <input
                  type="checkbox"
                  name="termsAccepted"
                  checked={formData.termsAccepted}
                  onChange={handleChange}
                  onBlur={handleBlur}
                />
                I accept the terms and conditions *
              </label>
              {errors.termsAccepted && touched.termsAccepted && (
                <span className="field-error">{errors.termsAccepted}</span>
              )}
            </div>

            {/* Submit button */}
            <button type="submit" className="submit-btn">
              Register
            </button>
          </form>
        </div>

        {/* Profile preview */}
        <div className="signup-preview-wrapper">
          <ProfilePreview formData={formData} />
        </div>
      </div>
    </div>
  )
}

export default SignUpForm