import React from 'react'
import { Link } from 'react-router-dom'
import { useAppContext } from '../context/AppContext'
import './Home.css'

function Home() {
  const { user } = useAppContext()

  return (
    <div className="home">
      {/* Hero Section */}
      <section className="hero-section">
        <div className="hero-content">
          
          <h1 className="hero-title">Richfield Connect</h1>
          <p className="hero-subtitle">Where academics meet and interact with each other daily! </p>
          <p className="hero-description">
            A dedicated platform that Richfield students use to connect, share ideas,collaborate
            and build academic networks in a professional online environment.
          </p>
         {!user && (
  <div className="hero-buttons">
    <Link to="/signup" className="hero-btn">
      Register Now
    </Link>
    <Link to="/login" className="hero-btn hero-btn-secondary">
      Login
    </Link>
  </div>
)}
          {user && (
            <div className="hero-welcome">
              <p>Welcome back, <strong>{user.name}</strong>!</p>
              <Link to="/feed" className="hero-btn hero-btn-secondary">
                Go to Feed
              </Link>
            </div>
          )}
        </div>
      </section>

      {/* Features Section */}
      <section className="features-section">
        
        <div className="features-grid">
          <div className="feature-card">
          
            <h3>Connect with Peers</h3>
            <p>Increase your personal network and make connections with your fellow students!</p>
          </div>

          <div className="feature-card">
           
            <h3>Share Academic Ideas</h3>
            <p>Engage with each other on intelligent and difficult topics, collaborate and share ideas!</p>
          </div>

          <div className="feature-card">
         
            <h3>Build Your Profile</h3>
            <p>Build your portfolio, express your passions and interests! </p>
          </div>
        </div>
      </section>
    </div>
  )
}

export default Home