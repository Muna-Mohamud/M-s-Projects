import React from 'react'
import { Link } from 'react-router-dom'
import './Footer.css'

function Footer() {
  return (
    <footer className="footer">
      <div className="footer-container">
        <div className="footer-section">
          <h4>Richfield Connect</h4>
          <p className="footer-tagline">Connect with each other!</p>
        </div>

        <div className="footer-section">
          <h5>Quick Links</h5>
          <Link to="/">Home</Link>
          <Link to="/about">About</Link>
          <Link to="/login">Login</Link>
          <Link to="/signup">Sign Up</Link>
        </div>

        <div className="footer-section">
          <h5>Contact</h5>
          <p>totallyrealemail@richfield.ac.za</p>
          <p>+27 67 676 6767</p>
          <p>Bryanston Campus, Johannesburg</p>
        </div>
      </div>

      <div className="footer-bottom">
        <p>&copy; {new Date().getFullYear()} Richfield Graduate Institute of Technology</p>
      </div>
    </footer>
  )
}

export default Footer