import React from 'react'
import './ProfilePreview.css'

function ProfilePreview({ formData }) {
  const { name, username, studentNumber, campus, interests, email, bio } = formData

  // Get initials for avatar
  const getInitials = () => {
    if (!name) return '?'
    return name
      .split(' ')
      .slice(0, 2)
      .map(word => word.charAt(0).toUpperCase())
      .join('')
  }

  return (
    <div className="profile-preview">
      <div className="preview-header">
        <h3>Live Profile Preview</h3>
        <span className="preview-badge">updates in real-time</span>
      </div>

      <div className="preview-body">
        {/* Avatar */}
        <div className="preview-avatar">
          <span className="avatar-initials">{getInitials()}</span>
        </div>

        {/* Name */}
        <div className="preview-field">
          <label>Full Name</label>
          <p className="preview-value">{name || <span className="placeholder">Not entered yet</span>}</p>
        </div>

        {/* Username */}
        <div className="preview-field">
          <label>Username</label>
          <p className="preview-value">{username || <span className="placeholder">Not entered yet</span>}</p>
        </div>

        {/* Student Number */}
        <div className="preview-field">
          <label>Student Number</label>
          <p className="preview-value">{studentNumber || <span className="placeholder">Not entered yet</span>}</p>
        </div>

        {/* Campus */}
        <div className="preview-field">
          <label>Campus</label>
          <p className="preview-value">{campus || <span className="placeholder">Not entered yet</span>}</p>
        </div>

        {/* Interests */}
        <div className="preview-field">
          <label>Interests</label>
          <div className="preview-interests">
            {interests && interests.length > 0 ? (
              interests.map((interest, index) => (
                <span key={index} className="preview-tag">
                  {interest}
                </span>
              ))
            ) : (
              <span className="placeholder">No interests selected</span>
            )}
          </div>
        </div>

        {/* Email */}
        <div className="preview-field">
          <label>Email</label>
          <p className="preview-value">{email || <span className="placeholder">Not entered yet</span>}</p>
        </div>

        {/* Bio */}
        <div className="preview-field">
          <label>Bio</label>
          <p className="preview-bio">{bio || <span className="placeholder">Not entered yet</span>}</p>
        </div>
      </div>
    </div>
  )
}

export default ProfilePreview