import React, { useState } from 'react'
import { useAppContext } from '../context/AppContext'
import './CreatePost.css'

function CreatePost() {
  const { user, addPost } = useAppContext()
  const [content, setContent] = useState('')
  const [error, setError] = useState('')

  const handleSubmit = (e) => {
    e.preventDefault()

    const trimmed = content.trim()
    if (!trimmed) {
      setError('Please write something before posting.')
      return
    }

    // allows user to create a new post
    const createdAt = new Date()
    const newPost = {
      id: Date.now(),
      username: user.username || 'Anonymous',
      content: trimmed,
      //A time stamp for the post 
      // an ISO timestamp for reliable date comparisons in the UI.
      timestamp: createdAt.toLocaleString('en-ZA', {
        dateStyle: 'medium',
        timeStyle: 'short',
      }),
      createdAt: createdAt.toISOString(),
      likes: 0,
      liked: false,
    }

    addPost(newPost)
    setContent('')
    setError('')

    // makes a user scroll to the top of the feed to see a new post
    const feedContainer = document.querySelector('.feed-posts')
    if (feedContainer) {
      feedContainer.scrollIntoView({ behavior: 'smooth', block: 'start' })
    }
  }

  return (
    <div className="create-post">
      <div className="create-post-header">
        <div className="create-post-avatar">
          <span>{user?.name?.charAt(0) || '?'}</span>
        </div>
        <div>
          <p className="create-post-user">{user?.name || 'User'}</p>
          <p className="create-post-status">Share your thoughts</p>
        </div>
      </div>

      <form onSubmit={handleSubmit}>
        <textarea
          className="create-post-textarea"
          placeholder="What's on your mind?"
          value={content}
          onChange={(e) => {
            setContent(e.target.value)
            if (error) setError('')
          }}
          rows="3"
        />
        {error && <span className="create-post-error">{error}</span>}

        <div className="create-post-actions">
          <span className="create-post-char-count">
            {content.length} characters
          </span>
          <button type="submit" className="create-post-btn">
            Post
          </button>
        </div>
      </form>
    </div>
  )
}

export default CreatePost
