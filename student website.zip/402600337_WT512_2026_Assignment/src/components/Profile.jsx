import React from 'react'
import { useNavigate } from 'react-router-dom'
import { useAppContext } from '../context/AppContext'
import './Profile.css'

function Profile() {
  const navigate = useNavigate()
  const { user } = useAppContext()

  // If there is no user, it redirects to signup
  if (!user) {
    return (
      <div className="profile-no-user">
        <p>No user profile found.</p>
        <button onClick={() => navigate('/signup')} className="btn-primary">
          Register Now
        </button>
      </div>
    )
  }

  // Get initials for profile avatar
  const getInitials = () => {
    if (!user.name) return '?'
    return user.name
      .split(' ')
      .slice(0, 2)
      .map(word => word.charAt(0).toUpperCase())
      .join('')
  }

  // Stats (static for demo purposes)
  const stats = {
    posts: 0,
    connections: 0,
    groups: 0,
  }

  return (
    <div className="profile-page">
      <div className="profile-card">
        {/* Profile Header */}
        <div className="profile-header">
          <div className="profile-avatar">
            <span className="avatar-initials">{getInitials()}</span>
          </div>
          <div className="profile-name-section">
            <h1 className="profile-name">{user.name}</h1>
            <p className="profile-username">@{user.username}</p>
          </div>
        </div>

        {/* Profile Details */}
        <div className="profile-details">
          <div className="detail-row">
            <span className="detail-label">Student Number</span>
            <span className="detail-value">{user.studentNumber}</span>
          </div>
          <div className="detail-row">
            <span className="detail-label">Campus</span>
            <span className="detail-value">{user.campus}</span>
          </div>
          <div className="detail-row">
            <span className="detail-label">Email</span>
            <span className="detail-value">{user.email}</span>
          </div>
          <div className="detail-row">
            <span className="detail-label">Interests</span>
            <div className="detail-tags">
              {user.interests && user.interests.length > 0 ? (
                user.interests.map((interest, index) => (
                  <span key={index} className="profile-tag">{interest}</span>
                ))
              ) : (
                <span className="text-muted">No interests listed</span>
              )}
            </div>
          </div>
          <div className="detail-row bio-row">
            <span className="detail-label">Bio</span>
            <p className="detail-bio">{user.bio || 'No bio provided'}</p>
          </div>
        </div>

        {/* Stats */}
        <div className="profile-stats">
          <div className="stat-item">
            <span className="stat-number">{stats.posts}</span>
            <span className="stat-label">Posts</span>
          </div>
          <div className="stat-divider"></div>
          <div className="stat-item">
            <span className="stat-number">{stats.connections}</span>
            <span className="stat-label">Connections</span>
          </div>
          <div className="stat-divider"></div>
          <div className="stat-item">
            <span className="stat-number">{stats.groups}</span>
            <span className="stat-label">Groups</span>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Profile