import React from 'react'
import './About.css'

function About() {
  return (
    <div className="about">


      <div className="about-columns">
        {/* Column 1 */}
        <div className="about-column">
          <h2>Our Purpose</h2>
          <p>
            Welcome to Richfield Connect! Richfield Connect is an academic based social engagement platform meant for the students of Richfield College.
          </p>
          <p>
            Here, students are allowed to collaborate, share, interact and also build their portfolio. This platform is meant to foster a sense of community and academic engagement among students. 
          </p>
        </div>

        {/* Column 2 text*/}
        <div className="about-column">
          <h2>Community Guidelines</h2>
          <ul className="guidelines-list">
            <li>No hate speech or bullying.</li>
            <li>Do not steal other people's work.</li>
            <li>Do not ostracize each other.</li>
            <li>Only academic related topics are allowed, this isn't Instagram.</li>
            <li>No inappropriate content</li>
          </ul>
        </div>

        {/* Column 3 text */}
        <div className="about-column">
          <h2>Contact Us</h2>
          <p><strong>Email:</strong> totallyrealemail@richfield.ac.za</p>
          <p><strong>Campus:</strong> Bryanston Campus, Johannesburg</p>
          <p><strong>Phone:</strong> +27 67 676 6767</p>
        </div>
      </div>
    </div>
  )
}

export default About