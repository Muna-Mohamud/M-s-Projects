import React, { useState } from 'react'
import { Link } from 'react-router-dom'
import { useAppContext } from '../context/AppContext'
import CreatePost from './CreatePost'
import Post from './Post'
import './Feed.css'

function Feed() {
  const { user, posts } = useAppContext()

  // If user is not registered or logged in, it will show this message
  if (!user) {
    return (
      <div className="feed-container">
        <div className="feed-empty">
          <p>Please sign up to view the feed.</p>
          <Link to="/signup" className="feed-cta">Sign Up Now</Link>
        </div>
      </div>
    )
  }

  return (
    <div className="feed-container">
      <div className="feed-header">
        <h2>Feed Page</h2>
       
      </div>

      <CreatePost />

      <div className="feed-posts">
        {posts.length === 0 ? (
          <div className="feed-empty">
            <p>No posts yet.</p>
          </div>
        ) : (
          posts.map(post => (
            <Post key={post.id} post={post} />
          ))
        )}
      </div>
    </div>
  )
}

export default Feed
