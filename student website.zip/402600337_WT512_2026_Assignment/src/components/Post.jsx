import React from 'react'
import { useAppContext } from '../context/AppContext'
import './Post.css'

function Post({ post }) {
  const { user, toggleLike, deletePost } = useAppContext()

  const handleLike = () => {
    if (!user) return
    toggleLike(post.id)
  }

  const handleDelete = () => {
    if (window.confirm('Are you sure you want to delete this post?')) {
      deletePost(post.id)
    }
  }

  // Format timestamp
  const formatTime = (timestamp) => {
    const date = new Date(post.createdAt || timestamp)
    if (Number.isNaN(date.getTime())) return timestamp
    const now = new Date()
    const diff = Math.floor((now - date) / 1000)

    if (diff < 60) return 'Just now'
    if (diff < 3600) return `${Math.floor(diff / 60)}m ago`
    if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`
    if (diff < 604800) return `${Math.floor(diff / 86400)}d ago`
    return timestamp
  }

  return (
    <div className="post-card">
      {/* Header */}
      <div className="post-header">
        <div className="post-avatar">
          <span>{post.username?.charAt(0).toUpperCase() || '?'}</span>
        </div>
        <div className="post-meta">
          <span className="post-username">@{post.username}</span>
          <span className="post-time">{formatTime(post.timestamp)}</span>
        </div>
        <button className="post-delete-btn" onClick={handleDelete}>
          Delete
        </button>
      </div>

      {/* Content */}
      <div className="post-content">
        <p>{post.content}</p>
      </div>

      {/* Actions */}
      <div className="post-actions">
        <button
          className={`post-like-btn ${post.liked ? 'liked' : ''}`}
          onClick={handleLike}
          disabled={!user}
        >
          <span className="like-label">{post.liked ? 'Liked' : 'Like'}</span>
          <span className="like-count">{post.likes}</span>
        </button>
      </div>
    </div>
  )
}

export default Post
