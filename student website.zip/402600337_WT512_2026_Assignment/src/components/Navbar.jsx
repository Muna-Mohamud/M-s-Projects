import React from 'react'
import { Link, NavLink, useNavigate } from 'react-router-dom'
import { useAppContext } from '../context/AppContext'
import './Navbar.css'

function Navbar() {
  const { user, logoutUser } = useAppContext()
  const navigate = useNavigate()

  const handleLogout = () => {
    if (window.confirm('Are you sure you want to log out?')) {
      logoutUser()
      navigate('/')
    }
  }

  return (
    <nav className="navbar">
      <div className="navbar-container">
        <Link to="/" className="navbar-brand">
         
          <span className="brand-text">Richfield Connect</span>
        </Link>

        <div className="navbar-links">
          <NavLink to="/" className={({ isActive }) =>
            isActive ? 'nav-link active' : 'nav-link'
          } end>
            Home
          </NavLink>
          <NavLink to="/about" className={({ isActive }) =>
            isActive ? 'nav-link active' : 'nav-link'
          }>
            About
          </NavLink>

          {user ? (
            <>
              <NavLink to="/feed" className={({ isActive }) =>
                isActive ? 'nav-link active' : 'nav-link'
              }>
                Feed
              </NavLink>
              <NavLink to="/profile" className={({ isActive }) =>
                isActive ? 'nav-link active' : 'nav-link'
              }>
                Profile
              </NavLink>
              <button onClick={handleLogout} className="logout-btn-nav">
                Logout
              </button>
            </>
          ) : (
            <>
              <NavLink to="/login" className={({ isActive }) =>
                isActive ? 'nav-link active' : 'nav-link'
              }>
                Login
              </NavLink>
              <NavLink to="/signup" className={({ isActive }) =>
                isActive ? 'nav-link active signup-link' : 'nav-link signup-link'
              }>
                Sign Up
              </NavLink>
            </>
          )}
        </div>

        {user && (
          <div className="navbar-user">
            <span className="user-greeting">Welcome, {user.name}</span>
          </div>
        )}
      </div>
    </nav>
  )
}

export default Navbar