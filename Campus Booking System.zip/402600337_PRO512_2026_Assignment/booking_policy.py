"""
Booking policies for the Smart Campus Resource Booking System.
Implements the Strategy pattern for campus-specific rules.
"""

from abc import ABC, abstractmethod


class BookingPolicy(ABC):
    
    @abstractmethod
    def validate_booking(self, booking_data):
        """
        Validate a booking against the policy.
        
        Args:
            booking_data (dict): Contains 'duration', 'start_time', 'user_role'
        
        Returns:
            tuple: (is_valid, message)
        """
        pass
    
    @abstractmethod
    def get_policy_description(self):
        """Return a description of the booking policy."""
        pass


class DurbanCampusPolicy(BookingPolicy):
    """Durban Campus booking policy - Max 3 hours, 07:00-20:00, Lecturers only."""
    
    def validate_booking(self, booking_data):
        duration = booking_data.get('duration', 0)
        start_time = booking_data.get('start_time', '')
        user_role = booking_data.get('user_role', '')
        
        if user_role != 'lecturer':
            return False, "Durban campus: Only lecturers can book resources."
        
        if duration > 3:
            return False, "Durban campus: Maximum booking duration is 3 hours."
        
        if start_time:
            hour = int(start_time.split(':')[0])
            if hour < 7 or hour >= 20:
                return False, "Durban campus: Bookings only allowed between 07:00 and 20:00."
        
        return True, "Booking valid for Durban campus."
    
    def get_policy_description(self):
        return "Durban Campus: Max 3 hours, 07:00-20:00, Lecturers only"


class CapeTownCampusPolicy(BookingPolicy):
    """Cape Town Campus booking policy - Max 4 hours, 08:00-22:00, Lecturers only."""
    
    def validate_booking(self, booking_data):
        duration = booking_data.get('duration', 0)
        start_time = booking_data.get('start_time', '')
        user_role = booking_data.get('user_role', '')
        
        if user_role != 'lecturer':
            return False, "Cape Town campus: Only lecturers can book resources."
        
        if duration > 4:
            return False, "Cape Town campus: Maximum booking duration is 4 hours."
        
        if start_time:
            hour = int(start_time.split(':')[0])
            if hour < 8 or hour >= 22:
                return False, "Cape Town campus: Bookings only allowed between 08:00 and 22:00."
        
        return True, "Booking valid for Cape Town campus."
    
    def get_policy_description(self):
        return "Cape Town Campus: Max 4 hours, 08:00-22:00, Lecturers only"


class JohannesburgCampusPolicy(BookingPolicy):
    """Johannesburg Campus booking policy - Max 2 hours, 09:00-17:00, Lecturers only."""
    
    def validate_booking(self, booking_data):
        duration = booking_data.get('duration', 0)
        start_time = booking_data.get('start_time', '')
        user_role = booking_data.get('user_role', '')
        
        if user_role != 'lecturer':
            return False, "Johannesburg campus: Only lecturers can book resources."
        
        if duration > 2:
            return False, "Johannesburg campus: Maximum booking duration is 2 hours."
        
        if start_time:
            hour = int(start_time.split(':')[0])
            if hour < 9 or hour >= 17:
                return False, "Johannesburg campus: Bookings only allowed between 09:00 and 17:00."
        
        return True, "Booking valid for Johannesburg campus."
    
    def get_policy_description(self):
        return "Johannesburg Campus: Max 2 hours, 09:00-17:00, Lecturers only"


def get_booking_policy(campus_name):
   
    policies = {
        'Durban': DurbanCampusPolicy,
        'Cape Town': CapeTownCampusPolicy,
        'Johannesburg': JohannesburgCampusPolicy,
    }
    
    policy_class = policies.get(campus_name)
    if policy_class:
        return policy_class()
    
    # Default policy if campus not found - ensures system always works
    class DefaultPolicy(BookingPolicy):
        def validate_booking(self, data):
            return True, "No restrictions"
        def get_policy_description(self):
            return "Default Policy: No restrictions"
    
    return DefaultPolicy()