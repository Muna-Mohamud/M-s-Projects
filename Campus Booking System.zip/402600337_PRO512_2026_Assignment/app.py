"""
Main GUI Application for the Smart Campus Resource Booking System.
"""

import tkinter as tk
from tkinter import ttk, messagebox
import datetime
import re

from database_manager import DatabaseManager
from user_models import Lecturer, CampusAdministrator, SystemOperator
from booking_policy import get_booking_policy


class SmartCampusBookingApp:
   
    
    # Defines the campus names as class constant
    CAMPUS_NAMES = ['Durban', 'Cape Town', 'Johannesburg']
    
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Smart Campus Resource Booking System")
        self.root.geometry("1000x700")
        self.root.configure(bg='#2c3e50')
        
        self.db = DatabaseManager()
        self.current_user = None
        self.current_campus = None
        self.user_role = None
        self.content_panel = None
        
        # Initialise the data
        self._init_campuses()
        self._init_test_users()
        
        # displays the login screen
        self._create_login_screen()
        
        self.root.mainloop()
    
    def _add_default_resources(self):
        """Add default resources to each campus."""
        print("Adding default resources...")
        
        # defines the durban Campus Resources
        durban_resources = [
            ('Computer Lab 1', 'Computer Lab', 'Durban', 30),
            ('Computer Lab 2', 'Computer Lab', 'Durban', 25),
            ('Multimedia Projector A', 'Projector', 'Durban', 1),
            ('Seminar Room 101', 'Seminar Room', 'Durban', 20),
            ('Presentation Equipment Kit', 'Equipment', 'Durban', 1),
        ]
        
        # Cape Town Campus Resources
        capetown_resources = [
            ('Computer Lab North', 'Computer Lab', 'Cape Town', 35),
            ('Projector Suite', 'Projector', 'Cape Town', 2),
            ('Seminar Room 200', 'Seminar Room', 'Cape Town', 15),
            ('AV Equipment', 'Equipment', 'Cape Town', 1),
        ]
        
        # Johannesburg Campus Resources
        johannesburg_resources = [
            ('Computer Lab Central', 'Computer Lab', 'Johannesburg', 20),
            ('Projector Hall', 'Projector', 'Johannesburg', 1),
            ('Seminar Room 300', 'Seminar Room', 'Johannesburg', 12),
            ('Presentation Kit', 'Equipment', 'Johannesburg', 1),
        ]
        
        for resource in durban_resources:
            self.db.add_resource(resource[0], resource[1], resource[2], resource[3])
            print(f"  Added: {resource[0]} to {resource[2]}")
        
        for resource in capetown_resources:
            self.db.add_resource(resource[0], resource[1], resource[2], resource[3])
            print(f"  Added: {resource[0]} to {resource[2]}")
        
        for resource in johannesburg_resources:
            self.db.add_resource(resource[0], resource[1], resource[2], resource[3])
            print(f"  Added: {resource[0]} to {resource[2]}")
        
        print("All resources added successfully!")
    
    def _init_campuses(self):
        """Initialize default campuses and resources if they don't exist"""
        campuses = self.db.get_all_campuses()
        print(f"Found {len(campuses)} campuses in database")
        
        if not campuses:
            print("No campuses found - creating default campuses")
            campuses_data = [
                ('Durban', 'KwaZulu-Natal', 3, '07:00', '20:00', 'lecturers'),
                ('Cape Town', 'Western Cape', 4, '08:00', '22:00', 'lecturers'),
                ('Johannesburg', 'Gauteng', 2, '09:00', '17:00', 'lecturers')
            ]
            for campus in campuses_data:
                print(f"  Adding campus: {campus[0]}")
                self.db.add_campus(*campus)
            
            self._add_default_resources()
        else:
            for campus in campuses:
                resources = self.db.get_resources_by_campus(campus['name'])
                print(f"  {campus['name']} has {len(resources)} resources")
                if len(resources) == 0:
                    print(f"  Adding default resources for {campus['name']}")
                    if campus['name'] == 'Durban':
                        resources_to_add = [
                            ('Computer Lab 1', 'Computer Lab', 'Durban', 30),
                            ('Computer Lab 2', 'Computer Lab', 'Durban', 25),
                            ('Multimedia Projector A', 'Projector', 'Durban', 1),
                            ('Seminar Room 101', 'Seminar Room', 'Durban', 20),
                            ('Presentation Equipment Kit', 'Equipment', 'Durban', 1),
                        ]
                    elif campus['name'] == 'Cape Town':
                        resources_to_add = [
                            ('Computer Lab North', 'Computer Lab', 'Cape Town', 35),
                            ('Projector Suite', 'Projector', 'Cape Town', 2),
                            ('Seminar Room 200', 'Seminar Room', 'Cape Town', 15),
                            ('AV Equipment', 'Equipment', 'Cape Town', 1),
                        ]
                    elif campus['name'] == 'Johannesburg':
                        resources_to_add = [
                            ('Computer Lab Central', 'Computer Lab', 'Johannesburg', 20),
                            ('Projector Hall', 'Projector', 'Johannesburg', 1),
                            ('Seminar Room 300', 'Seminar Room', 'Johannesburg', 12),
                            ('Presentation Kit', 'Equipment', 'Johannesburg', 1),
                        ]
                    else:
                        resources_to_add = []
                    
                    for resource in resources_to_add:
                        self.db.add_resource(resource[0], resource[1], resource[2], resource[3])
                        print(f"    Added: {resource[0]}")
        
        # Verifying if there are resources after initialization
        print("\n RESOURCE VERIFICATION ")
        for campus in self.CAMPUS_NAMES:
            resources = self.db.get_resources_by_campus(campus)
            print(f"{campus}: {len(resources)} resources")
            for r in resources[:3]:
                print(f"  - {r['resource_name']} ({r['resource_type']})")
        print("-----\n")
    
    def _init_test_users(self):
        """backup user accounts for demonstration."""
        users = [
            ('lecturer1', 'pass123', 'lecturer', 'Durban', 'Dr. Smith', 'smith@richfield.ac.za'),
            ('lecturer2', 'pass123', 'lecturer', 'Cape Town', 'Dr. Johnson', 'johnson@richfield.ac.za'),
            ('lecturer3', 'pass123', 'lecturer', 'Johannesburg', 'Dr. Williams', 'williams@richfield.ac.za'),
            ('admin1', 'pass123', 'admin', 'Durban', 'Admin Durban', 'admin.durban@richfield.ac.za'),
            ('admin2', 'pass123', 'admin', 'Cape Town', 'Admin Cape Town', 'admin.capetown@richfield.ac.za'),
            ('admin3', 'pass123', 'admin', 'Johannesburg', 'Admin Johannesburg', 'admin.johannesburg@richfield.ac.za'),
            ('operator1', 'pass123', 'operator', '', 'System Operator', 'operator@richfield.ac.za'),
        ]
        
        for user in users:
            existing = self.db.get_user_by_username(user[0])
            if not existing:
                success, message = self.db.register_user(*user)
                if success:
                    print(f"Created test user: {user[0]} ({user[2]})")
                else:
                    print(f"Failed to create user {user[0]}: {message}")
    
    def _create_login_screen(self):
        """this creates the login screen GUI."""
        for widget in self.root.winfo_children():
            widget.destroy()
        
        main_frame = tk.Frame(self.root, bg='#2c3e50')
        main_frame.place(relx=0.5, rely=0.5, anchor='center')
        
        title_label = tk.Label(main_frame, text="Smart Campus Resource Booking System", 
                               font=('Helvetica', 24, 'bold'), 
                               fg='white', bg='#2c3e50')
        title_label.pack(pady=20)
        
        subtitle_label = tk.Label(main_frame, text="Richfield Graduate Institution", 
                                  font=('Helvetica', 14), 
                                  fg='#bdc3c7', bg='#2c3e50')
        subtitle_label.pack(pady=(0, 30))
        
        login_box = tk.Frame(main_frame, bg='#34495e', relief='groove', bd=2)
        login_box.pack(pady=20, padx=40)
        
        tk.Label(login_box, text="Username:", font=('Helvetica', 12), 
                fg='white', bg='#34495e').grid(row=0, column=0, padx=20, pady=15, sticky='w')
        self.username_entry = tk.Entry(login_box, font=('Helvetica', 12), width=25)
        self.username_entry.grid(row=0, column=1, padx=20, pady=15)
        self.username_entry.insert(0, "lecturer1")
        
        tk.Label(login_box, text="Password:", font=('Helvetica', 12), 
                fg='white', bg='#34495e').grid(row=1, column=0, padx=20, pady=15, sticky='w')
        self.password_entry = tk.Entry(login_box, font=('Helvetica', 12), width=25, show='*')
        self.password_entry.grid(row=1, column=1, padx=20, pady=15)
        self.password_entry.insert(0, "pass123")
        
        login_button = tk.Button(main_frame, text="Login", font=('Helvetica', 14, 'bold'),
                                bg='#27ae60', fg='white', padx=50, pady=10,
                                command=self._handle_login)
        login_button.pack(pady=20)
        
        register_button = tk.Button(main_frame, text="Create Account", font=('Helvetica', 12),
                                   bg='#3498db', fg='white', padx=30, pady=8,
                                   command=self._create_registration_screen)
        register_button.pack(pady=5)
    
    def _create_registration_screen(self):
        """this creates the registration screen GUI."""
        for widget in self.root.winfo_children():
            widget.destroy()
        
        main_frame = tk.Frame(self.root, bg='#2c3e50')
        main_frame.place(relx=0.5, rely=0.5, anchor='center')
        
        tk.Label(main_frame, text="Create Account", 
                font=('Helvetica', 24, 'bold'), fg='white', bg='#2c3e50').pack(pady=20)
        
        reg_box = tk.Frame(main_frame, bg='#34495e', relief='groove', bd=2)
        reg_box.pack(pady=20, padx=40)
        
        tk.Label(reg_box, text="Full Name:", font=('Helvetica', 12), 
                fg='white', bg='#34495e').grid(row=0, column=0, padx=20, pady=10, sticky='w')
        self.reg_name_entry = tk.Entry(reg_box, font=('Helvetica', 12), width=25)
        self.reg_name_entry.grid(row=0, column=1, padx=20, pady=10)
        
        tk.Label(reg_box, text="Email:", font=('Helvetica', 12), 
                fg='white', bg='#34495e').grid(row=1, column=0, padx=20, pady=10, sticky='w')
        self.reg_email_entry = tk.Entry(reg_box, font=('Helvetica', 12), width=25)
        self.reg_email_entry.grid(row=1, column=1, padx=20, pady=10)
        
        tk.Label(reg_box, text="Username:", font=('Helvetica', 12), 
                fg='white', bg='#34495e').grid(row=2, column=0, padx=20, pady=10, sticky='w')
        self.reg_username_entry = tk.Entry(reg_box, font=('Helvetica', 12), width=25)
        self.reg_username_entry.grid(row=2, column=1, padx=20, pady=10)
        
        tk.Label(reg_box, text="Password:", font=('Helvetica', 12), 
                fg='white', bg='#34495e').grid(row=3, column=0, padx=20, pady=10, sticky='w')
        self.reg_password_entry = tk.Entry(reg_box, font=('Helvetica', 12), width=25, show='*')
        self.reg_password_entry.grid(row=3, column=1, padx=20, pady=10)
        
        tk.Label(reg_box, text="Role:", font=('Helvetica', 12), 
                fg='white', bg='#34495e').grid(row=4, column=0, padx=20, pady=10, sticky='w')
        self.reg_role_var = tk.StringVar(value="lecturer")
        role_menu = ttk.Combobox(reg_box, textvariable=self.reg_role_var, 
                                 values=['lecturer', 'admin', 'operator'], 
                                 font=('Helvetica', 12), width=23, state='readonly')
        role_menu.grid(row=4, column=1, padx=20, pady=10)
        
        tk.Label(reg_box, text="Campus:", font=('Helvetica', 12), 
                fg='white', bg='#34495e').grid(row=5, column=0, padx=20, pady=10, sticky='w')
        self.reg_campus_var = tk.StringVar(value="")
        campus_menu = ttk.Combobox(reg_box, textvariable=self.reg_campus_var,
                                   values=['', 'Durban', 'Cape Town', 'Johannesburg'],
                                   font=('Helvetica', 12), width=23, state='readonly')
        campus_menu.grid(row=5, column=1, padx=20, pady=10)
        
        reg_button = tk.Button(main_frame, text="Register", font=('Helvetica', 14, 'bold'),
                              bg='#27ae60', fg='white', padx=50, pady=10,
                              command=self._handle_registration)
        reg_button.pack(pady=20)
        
        back_button = tk.Button(main_frame, text="Back to Login", font=('Helvetica', 12),
                               bg='#7f8c8d', fg='white', padx=20, pady=8,
                               command=self._create_login_screen)
        back_button.pack(pady=5)
    
    def _handle_login(self):
        """handles the login process."""
        username = self.username_entry.get().strip()
        password = self.password_entry.get().strip()
        
        if not username or not password:
            messagebox.showerror("Error", "Please enter username and password.")
            return
        
        user_data = self.db.authenticate_user(username, password)
        
        if user_data:
            self.current_user = username
            self.user_role = user_data['role']
            self.current_campus = user_data['campus_name']
            
            messagebox.showinfo("Success", f"Welcome, {user_data['full_name'] or username}!")
            self._create_main_menu()
        else:
            messagebox.showerror("Error", "Invalid username or password.")
    
    def _handle_registration(self):
        """Handle the registration process."""
        username = self.reg_username_entry.get().strip()
        password = self.reg_password_entry.get().strip()
        full_name = self.reg_name_entry.get().strip()
        email = self.reg_email_entry.get().strip()
        role = self.reg_role_var.get()
        campus = self.reg_campus_var.get()
        
        if not username or not password:
            messagebox.showerror("Error", "Username and password are required.")
            return
        
        if len(password) < 4:
            messagebox.showerror("Error", "Password must be at least 4 characters.")
            return
        
        if role in ['lecturer', 'admin']:
            if not campus:
                messagebox.showerror("Error", "Please select a campus for this role.")
                return
            campus_data = self.db.get_campus_by_name(campus)
            if not campus_data:
                messagebox.showerror("Error", f"Campus '{campus}' does not exist.")
                return
        
        if email and '@' not in email:
            messagebox.showerror("Error", "Please enter a valid email address.")
            return
        
        success, message = self.db.register_user(username, password, role, campus, full_name, email)
        
        if success:
            messagebox.showinfo("Success", "Registration successful! Please login.")
            self._create_login_screen()
        else:
            messagebox.showerror("Error", message)
    
    def _create_main_menu(self):
        """Creates the main menu screen based on user role."""
        for widget in self.root.winfo_children():
            widget.destroy()
        
        header_frame = tk.Frame(self.root, bg='#2c3e50', height=80)
        header_frame.pack(fill='x')
        header_frame.pack_propagate(False)
        
        role_emoji = '📚' if self.user_role == 'lecturer' else '⚙️' if self.user_role == 'admin' else '📊'
        
        tk.Label(header_frame, text=f"{role_emoji} {self.user_role.capitalize()} Dashboard", 
                font=('Helvetica', 20, 'bold'), fg='white', bg='#2c3e50').pack(side='left', padx=20, pady=20)
        
        user_info = f"User: {self.current_user}"
        if self.current_campus:
            user_info += f" | Campus: {self.current_campus}"
        tk.Label(header_frame, text=user_info, font=('Helvetica', 12), 
                fg='#bdc3c7', bg='#2c3e50').pack(side='right', padx=20, pady=20)
        
        if self.user_role in ['lecturer', 'admin']:
            campus_frame = tk.Frame(self.root, bg='#34495e', height=50)
            campus_frame.pack(fill='x')
            campus_frame.pack_propagate(False)
            
            tk.Label(campus_frame, text="Select Campus:", font=('Helvetica', 12), 
                    fg='white', bg='#34495e').pack(side='left', padx=20, pady=10)
            
            self.campus_var = tk.StringVar(value=self.current_campus or 'Durban')
            campus_combo = ttk.Combobox(campus_frame, textvariable=self.campus_var,
                                        values=self.CAMPUS_NAMES,
                                        font=('Helvetica', 12), width=20, state='readonly')
            campus_combo.pack(side='left', padx=10, pady=10)
            
            policy = get_booking_policy(self.campus_var.get() or 'Durban')
            policy_label = tk.Label(campus_frame, text=f"📋 Policy: {policy.get_policy_description()}", 
                                   font=('Helvetica', 10), fg='#f1c40f', bg='#34495e')
            policy_label.pack(side='left', padx=20, pady=10)
            
            def update_campus():
                self.current_campus = self.campus_var.get()
                if self.current_campus:
                    policy = get_booking_policy(self.current_campus)
                    policy_label.config(text=f"📋 Policy: {policy.get_policy_description()}")
                    self._refresh_menu()
            
            campus_combo.bind('<<ComboboxSelected>>', lambda e: update_campus())
        
        content_frame = tk.Frame(self.root, bg='#ecf0f1')
        content_frame.pack(fill='both', expand=True, padx=10, pady=10)
        
        self._build_menu(content_frame)
    
    def _build_menu(self, parent):
        """responsible for building the menu buttons and content area."""
        for widget in parent.winfo_children():
            widget.destroy()
        
        menu_panel = tk.Frame(parent, bg='#34495e', width=250)
        menu_panel.pack(side='left', fill='y', padx=(0, 10))
        menu_panel.pack_propagate(False)
        
        tk.Label(menu_panel, text="Menu Options", font=('Helvetica', 14, 'bold'), 
                fg='white', bg='#34495e').pack(pady=15)
        
        # Get menu items based on role
        if self.user_role == 'lecturer':
            user_obj = Lecturer(self.current_user, '', self.current_campus)
        elif self.user_role == 'admin':
            user_obj = CampusAdministrator(self.current_user, '', self.current_campus)
        elif self.user_role == 'operator':
            user_obj = SystemOperator(self.current_user, '', self.current_campus)
        else:
            user_obj = Lecturer(self.current_user, '', self.current_campus)
        
        menu_items = user_obj.get_menu_items()
        
        self.menu_buttons = {}
        
        for item_text, item_id in menu_items:
            if item_id == "logout":
                btn = tk.Button(menu_panel, text="🚪 Logout", font=('Helvetica', 12),
                              bg='#e74c3c', fg='white', padx=20, pady=8,
                              command=self._logout)
                btn.pack(pady=5, padx=10, fill='x')
            else:
                btn = tk.Button(menu_panel, text=item_text, font=('Helvetica', 12),
                              bg='#2c3e50', fg='white', padx=20, pady=8,
                              command=lambda f=item_id: self._execute_menu_function(f))
                btn.pack(pady=5, padx=10, fill='x')
                self.menu_buttons[item_text] = btn
        
        content_panel = tk.Frame(parent, bg='white')
        content_panel.pack(side='right', fill='both', expand=True)
        
        tk.Label(content_panel, text="Welcome to the Smart Campus Resource Booking System", 
                font=('Helvetica', 18, 'bold'), fg='#2c3e50', bg='white').pack(pady=30)
        
        tk.Label(content_panel, text=f"Role: {self.user_role.capitalize()}", 
                font=('Helvetica', 14), fg='#34495e', bg='white').pack()
        
        if self.current_campus:
            tk.Label(content_panel, text=f"Active Campus: {self.current_campus}", 
                    font=('Helvetica', 14), fg='#34495e', bg='white').pack()
        
        policy = get_booking_policy(self.current_campus or 'Durban')
        tk.Label(content_panel, text=f"\n📋 Current Policy: {policy.get_policy_description()}", 
                font=('Helvetica', 12), fg='#2c3e50', bg='white').pack(pady=10)
        
        tk.Label(content_panel, text=f"\nSelect an option from the menu to get started.", 
                font=('Helvetica', 12), fg='#7f8c8d', bg='white').pack(pady=20)
        
        self.content_panel = content_panel
    
    def _execute_menu_function(self, function_name):
        """Execute a menu function based on function name."""
        try:
            if function_name == "view_resources":
                self._view_resources()
            elif function_name == "create_booking":
                self._create_booking()
            elif function_name == "view_active_bookings":
                self._view_active_bookings()
            elif function_name == "view_past_bookings":
                self._view_past_bookings()
            elif function_name == "cancel_booking":
                self._cancel_booking()
            elif function_name == "add_resource":
                self._add_resource()
            elif function_name == "update_resource":
                self._update_resource()
            elif function_name == "remove_resource":
                self._remove_resource()
            elif function_name == "monitor_availability":
                self._monitor_availability()
            elif function_name == "generate_report":
                self._generate_report()
            elif function_name == "view_campuses":
                self._view_campuses()
            elif function_name == "view_all_resources":
                self._view_all_resources()
            elif function_name == "view_all_bookings":
                self._view_all_bookings()
            elif function_name == "cross_campus_report":
                self._cross_campus_report()
            elif function_name == "add_campus":
                self._add_campus()
            elif function_name == "view_campus_bookings":
                self._view_campus_bookings()
            elif function_name == "view_bookings":
                self._view_bookings()
        except Exception as e:
            messagebox.showerror("Error", f"An error occurred: {str(e)}")
    
    def _refresh_menu(self):
        """Refresh the menu content."""
        if hasattr(self, 'content_panel'):
            self._build_menu(self.content_panel.master)
    
    def _logout(self):
        """Logout the current user."""
        if messagebox.askyesno("Logout", "Are you sure you want to logout?"):
            self.current_user = None
            self.user_role = None
            self.current_campus = None
            self._create_login_screen()
    
    #  LECTURER METHODS 
    
    def _view_resources(self):
        """View available resources for the selected campus."""
        if not self.current_campus:
            messagebox.showwarning("No Campus", "Please select a campus first.")
            return
        
        resources = self.db.get_resources_by_campus(self.current_campus)
        self._clear_content()
        
        tk.Label(self.content_panel, text=f" Available Resources - {self.current_campus}", 
                font=('Helvetica', 16, 'bold'), fg='#2c3e50', bg='white').pack(pady=20)
        
        if not resources:
            tk.Label(self.content_panel, text="No resources available for this campus.", 
                    font=('Helvetica', 12), fg='#7f8c8d', bg='white').pack(pady=20)
            return
        
        columns = ('ID', 'Name', 'Type', 'Capacity', 'Available')
        tree = ttk.Treeview(self.content_panel, columns=columns, show='headings')
        
        for col in columns:
            tree.heading(col, text=col)
            tree.column(col, width=120)
        
        for resource in resources:
            status = ' Available' if resource['is_available'] else 'Booked'
            tree.insert('', 'end', values=(
                resource['resource_id'],
                resource['resource_name'],
                resource['resource_type'],
                resource['capacity'],
                status
            ))
        
        tree.pack(fill='both', expand=True, padx=20, pady=10)
        
        tk.Button(self.content_panel, text="Back to Menu", font=('Helvetica', 12),
                 bg='#7f8c8d', fg='white', padx=20, pady=8,
                 command=self._refresh_menu).pack(pady=10)
    
    def _create_booking(self):
        """Create a new booking with policy validation."""
        if not self.current_campus:
            messagebox.showwarning("No Campus", "Please select a campus first.")
            return
        
        resources = self.db.get_resources_by_campus(self.current_campus)
        available_resources = [r for r in resources if r['is_available']]
        
        if not available_resources:
            messagebox.showwarning("No Resources", "No available resources for this campus.")
            return
        
        self._clear_content()
        
        tk.Label(self.content_panel, text=" Create New Booking", 
                font=('Helvetica', 16, 'bold'), fg='#2c3e50', bg='white').pack(pady=20)
        
        form_frame = tk.Frame(self.content_panel, bg='white')
        form_frame.pack(pady=20, padx=40)
        
        tk.Label(form_frame, text="Resource:", font=('Helvetica', 12), 
                bg='white').grid(row=0, column=0, padx=10, pady=10, sticky='w')
        
        resource_names = [f"{r['resource_name']} ({r['resource_type']})" for r in available_resources]
        self.booking_resource_var = tk.StringVar(value=resource_names[0] if resource_names else '')
        resource_combo = ttk.Combobox(form_frame, textvariable=self.booking_resource_var,
                                      values=resource_names, font=('Helvetica', 12), width=30)
        resource_combo.grid(row=0, column=1, padx=10, pady=10)
        
        tk.Label(form_frame, text="Date (YYYY-MM-DD):", font=('Helvetica', 12), 
                bg='white').grid(row=1, column=0, padx=10, pady=10, sticky='w')
        
        today = datetime.date.today()
        self.booking_date_var = tk.StringVar(value=today.strftime('%Y-%m-%d'))
        date_entry = tk.Entry(form_frame, textvariable=self.booking_date_var, 
                             font=('Helvetica', 12), width=30)
        date_entry.grid(row=1, column=1, padx=10, pady=10)
        
        tk.Label(form_frame, text="Start Time:", font=('Helvetica', 12), 
                bg='white').grid(row=2, column=0, padx=10, pady=10, sticky='w')
        
        times = [f"{h:02d}:00" for h in range(7, 22)]
        self.booking_time_var = tk.StringVar(value='08:00')
        time_combo = ttk.Combobox(form_frame, textvariable=self.booking_time_var,
                                  values=times, font=('Helvetica', 12), width=30)
        time_combo.grid(row=2, column=1, padx=10, pady=10)
        
        tk.Label(form_frame, text="Duration (hours):", font=('Helvetica', 12), 
                bg='white').grid(row=3, column=0, padx=10, pady=10, sticky='w')
        
        self.booking_duration_var = tk.StringVar(value='1')
        duration_spinbox = tk.Spinbox(form_frame, from_=1, to=4, 
                                      textvariable=self.booking_duration_var,
                                      font=('Helvetica', 12), width=10)
        duration_spinbox.grid(row=3, column=1, padx=10, pady=10, sticky='w')
        
        policy = get_booking_policy(self.current_campus)
        tk.Label(form_frame, text=f" Policy: {policy.get_policy_description()}", 
                font=('Helvetica', 10), fg='#f39c12', bg='white').grid(row=4, column=0, columnspan=2, pady=10)
        
        def submit_booking():
            resource_name = self.booking_resource_var.get()
            booking_date = self.booking_date_var.get()
            start_time = self.booking_time_var.get()
            duration = int(self.booking_duration_var.get())
            
            selected_resource = None
            for r in available_resources:
                if f"{r['resource_name']} ({r['resource_type']})" == resource_name:
                    selected_resource = r
                    break
            
            if not selected_resource:
                messagebox.showerror("Error", "Please select a resource.")
                return
            
            booking_data = {
                'duration': duration,
                'start_time': start_time,
                'user_role': self.user_role
            }
            is_valid, message = policy.validate_booking(booking_data)
            
            if not is_valid:
                messagebox.showerror("Policy Violation", message)
                return
            
            try:
                datetime.datetime.strptime(booking_date, '%Y-%m-%d')
            except ValueError:
                messagebox.showerror("Error", "Invalid date format. Use YYYY-MM-DD.")
                return
            
            try:
                booking_datetime = datetime.datetime.strptime(f"{booking_date} {start_time}", '%Y-%m-%d %H:%M')
                if booking_datetime < datetime.datetime.now():
                    messagebox.showerror("Error", "Cannot book a past date/time.")
                    return
            except:
                pass
            
            success, msg = self.db.create_booking(
                selected_resource['resource_id'],
                self.current_user,
                self.current_campus,
                booking_date,
                start_time,
                duration
            )
            
            if success:
                messagebox.showinfo("Success", " Booking created successfully!")
                self._refresh_menu()
            else:
                messagebox.showerror("Error", msg)
        
        tk.Button(self.content_panel, text="Submit Booking", font=('Helvetica', 14, 'bold'),
                 bg='#27ae60', fg='white', padx=40, pady=10,
                 command=submit_booking).pack(pady=20)
        
        tk.Button(self.content_panel, text="Cancel", font=('Helvetica', 12),
                 bg='#7f8c8d', fg='white', padx=20, pady=8,
                 command=self._refresh_menu).pack(pady=10)
    
    def _view_active_bookings(self):
        """View active/future bookings for a lecturer."""
        if not self.current_campus:
            messagebox.showwarning("No Campus", "Please select a campus first.")
            return
        
        bookings = self.db.get_active_bookings_by_username(self.current_user)
        self._display_bookings(" My Active Bookings", bookings, show_campus=True)
    
    def _view_past_bookings(self):
        """View past bookings for a lecturer."""
        if not self.current_campus:
            messagebox.showwarning("No Campus", "Please select a campus first.")
            return
        
        bookings = self.db.get_past_bookings_by_username(self.current_user)
        self._display_bookings("My Past Bookings", bookings, show_campus=True)
    
    def _view_campus_bookings(self):
        """View campus bookings (Admin only)."""
        if not self.current_campus:
            messagebox.showwarning("No Campus", "Please select a campus first.")
            return
        
        bookings = self.db.get_bookings_by_campus(self.current_campus)
        self._display_bookings(f" Campus Bookings - {self.current_campus}", bookings, show_user=True)
    
    def _display_bookings(self, title, bookings, show_campus=False, show_user=False):
        """Generic method to display bookings."""
        self._clear_content()
        
        tk.Label(self.content_panel, text=title, 
                font=('Helvetica', 16, 'bold'), fg='#2c3e50', bg='white').pack(pady=20)
        
        if not bookings:
            tk.Label(self.content_panel, text="No bookings found.", 
                    font=('Helvetica', 12), fg='#7f8c8d', bg='white').pack(pady=20)
            return
        
        if show_campus and show_user:
            columns = ('ID', 'Resource', 'User', 'Campus', 'Date', 'Start', 'Duration', 'End', 'Status')
        elif show_campus:
            columns = ('ID', 'Resource', 'Campus', 'Date', 'Start', 'Duration', 'End', 'Status')
        elif show_user:
            columns = ('ID', 'Resource', 'User', 'Date', 'Start', 'Duration', 'End', 'Status')
        else:
            columns = ('ID', 'Resource', 'Date', 'Start', 'Duration', 'End', 'Status')
        
        tree = ttk.Treeview(self.content_panel, columns=columns, show='headings', height=15)
        
        for col in columns:
            tree.heading(col, text=col)
            tree.column(col, width=100)
        
        for booking in bookings:
            status = ' Active' if booking['status'] == 'active' else ' Cancelled'
            if show_campus and show_user:
                values = (
                    booking['booking_id'],
                    booking['resource_name'],
                    booking['username'],
                    booking['campus_name'],
                    booking['booking_date'],
                    booking['start_time'],
                    booking['duration'],
                    booking['end_time'],
                    status
                )
            elif show_campus:
                values = (
                    booking['booking_id'],
                    booking['resource_name'],
                    booking['campus_name'],
                    booking['booking_date'],
                    booking['start_time'],
                    booking['duration'],
                    booking['end_time'],
                    status
                )
            elif show_user:
                values = (
                    booking['booking_id'],
                    booking['resource_name'],
                    booking['username'],
                    booking['booking_date'],
                    booking['start_time'],
                    booking['duration'],
                    booking['end_time'],
                    status
                )
            else:
                values = (
                    booking['booking_id'],
                    booking['resource_name'],
                    booking['booking_date'],
                    booking['start_time'],
                    booking['duration'],
                    booking['end_time'],
                    status
                )
            tree.insert('', 'end', values=values)
        
        tree.pack(fill='both', expand=True, padx=20, pady=10)
        
        tk.Button(self.content_panel, text="Back to Menu", font=('Helvetica', 12),
                 bg='#7f8c8d', fg='white', padx=20, pady=8,
                 command=self._refresh_menu).pack(pady=10)
    
    def _cancel_booking(self):
        """Cancel a future booking."""
        if not self.current_campus:
            messagebox.showwarning("No Campus", "Please select a campus first.")
            return
        
        bookings = self.db.get_active_bookings_by_username(self.current_user)
        
        if not bookings:
            messagebox.showinfo("No Bookings", "You have no active bookings to cancel.")
            return
        
        self._clear_content()
        
        tk.Label(self.content_panel, text="❌ Cancel Booking", 
                font=('Helvetica', 16, 'bold'), fg='#2c3e50', bg='white').pack(pady=20)
        
        booking_options = []
        for b in bookings:
            option = f"ID: {b['booking_id']} | {b['resource_name']} | {b['booking_date']} {b['start_time']}"
            booking_options.append(option)
        
        tk.Label(self.content_panel, text="Select booking to cancel:", font=('Helvetica', 12), 
                bg='white').pack(pady=10)
        
        self.cancel_booking_var = tk.StringVar(value=booking_options[0] if booking_options else '')
        booking_combo = ttk.Combobox(self.content_panel, textvariable=self.cancel_booking_var,
                                     values=booking_options, font=('Helvetica', 12), width=50)
        booking_combo.pack(pady=10)
        
        def submit_cancel():
            selected = self.cancel_booking_var.get()
            if not selected:
                messagebox.showwarning("No Selection", "Please select a booking to cancel.")
                return
            
            match = re.search(r'ID: (\d+)', selected)
            if not match:
                messagebox.showerror("Error", "Invalid selection.")
                return
            
            booking_id = int(match.group(1))
            
            if messagebox.askyesno("Confirm Cancel", "Are you sure you want to cancel this booking?"):
                success = self.db.cancel_booking(booking_id)
                if success:
                    messagebox.showinfo("Success", " Booking cancelled successfully!")
                    self._refresh_menu()
                else:
                    messagebox.showerror("Error", "Failed to cancel booking.")
        
        tk.Button(self.content_panel, text="Cancel Booking", font=('Helvetica', 14, 'bold'),
                 bg='#e74c3c', fg='white', padx=40, pady=10,
                 command=submit_cancel).pack(pady=20)
        
        tk.Button(self.content_panel, text="Back to Menu", font=('Helvetica', 12),
                 bg='#7f8c8d', fg='white', padx=20, pady=8,
                 command=self._refresh_menu).pack(pady=10)
    
    # ADMIN METHODS 
    
    def _add_resource(self):
        """Add a new resource (Admin only)."""
        if not self.current_campus:
            messagebox.showwarning("No Campus", "Please select a campus first.")
            return
        
        self._clear_content()
        
        tk.Label(self.content_panel, text=" Add New Resource", 
                font=('Helvetica', 16, 'bold'), fg='#2c3e50', bg='white').pack(pady=20)
        
        form_frame = tk.Frame(self.content_panel, bg='white')
        form_frame.pack(pady=20, padx=40)
        
        tk.Label(form_frame, text="Resource Name:", font=('Helvetica', 12), 
                bg='white').grid(row=0, column=0, padx=10, pady=10, sticky='w')
        self.add_resource_name = tk.Entry(form_frame, font=('Helvetica', 12), width=30)
        self.add_resource_name.grid(row=0, column=1, padx=10, pady=10)
        
        tk.Label(form_frame, text="Resource Type:", font=('Helvetica', 12), 
                bg='white').grid(row=1, column=0, padx=10, pady=10, sticky='w')
        self.add_resource_type = ttk.Combobox(form_frame, 
                                             values=['Computer Lab', 'Projector', 'Seminar Room', 'Equipment'],
                                             font=('Helvetica', 12), width=28)
        self.add_resource_type.grid(row=1, column=1, padx=10, pady=10)
        self.add_resource_type.set('Computer Lab')
        
        tk.Label(form_frame, text="Capacity:", font=('Helvetica', 12), 
                bg='white').grid(row=2, column=0, padx=10, pady=10, sticky='w')
        self.add_resource_capacity = tk.Spinbox(form_frame, from_=1, to=100,
                                               font=('Helvetica', 12), width=10)
        self.add_resource_capacity.grid(row=2, column=1, padx=10, pady=10, sticky='w')
        self.add_resource_capacity.delete(0, 'end')
        self.add_resource_capacity.insert(0, '1')
        
        def submit_resource():
            name = self.add_resource_name.get().strip()
            rtype = self.add_resource_type.get()
            capacity = int(self.add_resource_capacity.get())
            
            if not name:
                messagebox.showerror("Error", "Resource name is required.")
                return
            
            success = self.db.add_resource(name, rtype, self.current_campus, capacity)
            
            if success:
                messagebox.showinfo("Success", f"Resource '{name}' added successfully!")
                self._refresh_menu()
            else:
                messagebox.showerror("Error", "Resource already exists.")
        
        tk.Button(self.content_panel, text="Add Resource", font=('Helvetica', 14, 'bold'),
                 bg='#27ae60', fg='white', padx=40, pady=10,
                 command=submit_resource).pack(pady=20)
        
        tk.Button(self.content_panel, text="Back to Menu", font=('Helvetica', 12),
                 bg='#7f8c8d', fg='white', padx=20, pady=8,
                 command=self._refresh_menu).pack(pady=10)
    
    def _update_resource(self):
        """Update an existing resource (Admin only)."""
        if not self.current_campus:
            messagebox.showwarning("No Campus", "Please select a campus first.")
            return
        
        resources = self.db.get_resources_by_campus(self.current_campus)
        
        if not resources:
            messagebox.showinfo("No Resources", "No resources to update.")
            return
        
        self._clear_content()
        
        tk.Label(self.content_panel, text=" Update Resource", 
                font=('Helvetica', 16, 'bold'), fg='#2c3e50', bg='white').pack(pady=20)
        
        resource_options = [f"{r['resource_id']}: {r['resource_name']} ({r['resource_type']})" for r in resources]
        
        tk.Label(self.content_panel, text="Select Resource:", font=('Helvetica', 12), 
                bg='white').pack(pady=10)
        
        self.update_resource_var = tk.StringVar(value=resource_options[0])
        resource_combo = ttk.Combobox(self.content_panel, textvariable=self.update_resource_var,
                                      values=resource_options, font=('Helvetica', 12), width=40)
        resource_combo.pack(pady=10)
        
        self.update_available_var = tk.BooleanVar(value=True)
        tk.Checkbutton(self.content_panel, text="Resource Available", variable=self.update_available_var,
                      font=('Helvetica', 12), bg='white').pack(pady=10)
        
        def submit_update():
            selected = self.update_resource_var.get()
            match = re.search(r'^(\d+):', selected)
            if not match:
                messagebox.showerror("Error", "Invalid selection.")
                return
            
            resource_id = int(match.group(1))
            is_available = self.update_available_var.get()
            
            success = self.db.update_resource_availability(resource_id, is_available)
            
            if success:
                messagebox.showinfo("Success", " Resource updated successfully!")
                self._refresh_menu()
            else:
                messagebox.showerror("Error", "Failed to update resource.")
        
        tk.Button(self.content_panel, text="Update Resource", font=('Helvetica', 14, 'bold'),
                 bg='#f39c12', fg='white', padx=40, pady=10,
                 command=submit_update).pack(pady=20)
        
        tk.Button(self.content_panel, text="Back to Menu", font=('Helvetica', 12),
                 bg='#7f8c8d', fg='white', padx=20, pady=8,
                 command=self._refresh_menu).pack(pady=10)
    
    def _remove_resource(self):
        """Remove a resource (Admin only)."""
        if not self.current_campus:
            messagebox.showwarning("No Campus", "Please select a campus first.")
            return
        
        resources = self.db.get_resources_by_campus(self.current_campus)
        
        if not resources:
            messagebox.showinfo("No Resources", "No resources to remove.")
            return
        
        self._clear_content()
        
        tk.Label(self.content_panel, text=" Remove Resource", 
                font=('Helvetica', 16, 'bold'), fg='#2c3e50', bg='white').pack(pady=20)
        
        resource_options = [f"{r['resource_id']}: {r['resource_name']} ({r['resource_type']})" for r in resources]
        
        tk.Label(self.content_panel, text="Select Resource to Remove:", font=('Helvetica', 12), 
                bg='white').pack(pady=10)
        
        self.remove_resource_var = tk.StringVar(value=resource_options[0])
        resource_combo = ttk.Combobox(self.content_panel, textvariable=self.remove_resource_var,
                                      values=resource_options, font=('Helvetica', 12), width=40)
        resource_combo.pack(pady=10)
        
        def submit_remove():
            selected = self.remove_resource_var.get()
            match = re.search(r'^(\d+):', selected)
            if not match:
                messagebox.showerror("Error", "Invalid selection.")
                return
            
            resource_id = int(match.group(1))
            
            if messagebox.askyesno("Confirm Remove", "Are you sure you want to remove this resource?"):
                success = self.db.delete_resource(resource_id)
                if success:
                    messagebox.showinfo("Success", " Resource removed successfully!")
                    self._refresh_menu()
                else:
                    messagebox.showerror("Error", "Failed to remove resource.")
        
        tk.Button(self.content_panel, text="Remove Resource", font=('Helvetica', 14, 'bold'),
                 bg='#e74c3c', fg='white', padx=40, pady=10,
                 command=submit_remove).pack(pady=20)
        
        tk.Button(self.content_panel, text="Back to Menu", font=('Helvetica', 12),
                 bg='#7f8c8d', fg='white', padx=20, pady=8,
                 command=self._refresh_menu).pack(pady=10)
    
    def _monitor_availability(self):
        """Monitor resource availability (Admin only)."""
        if not self.current_campus:
            messagebox.showwarning("No Campus", "Please select a campus first.")
            return
        
        resources = self.db.get_resources_by_campus(self.current_campus)
        bookings = self.db.get_bookings_by_campus(self.current_campus)
        
        self._clear_content()
        
        tk.Label(self.content_panel, text=f" Resource Availability - {self.current_campus}", 
                font=('Helvetica', 16, 'bold'), fg='#2c3e50', bg='white').pack(pady=20)
        
        total = len(resources)
        available = sum(1 for r in resources if r['is_available'])
        
        summary_frame = tk.Frame(self.content_panel, bg='white')
        summary_frame.pack(pady=20)
        
        tk.Label(summary_frame, text=f"Total Resources: {total}", 
                font=('Helvetica', 12), bg='white').pack(side='left', padx=20)
        tk.Label(summary_frame, text=f"Available: {available}", 
                font=('Helvetica', 12), fg='green', bg='white').pack(side='left', padx=20)
        tk.Label(summary_frame, text=f"Booked: {total - available}", 
                font=('Helvetica', 12), fg='red', bg='white').pack(side='left', padx=20)
        
        columns = ('ID', 'Name', 'Type', 'Capacity', 'Status')
        tree = ttk.Treeview(self.content_panel, columns=columns, show='headings', height=10)
        
        for col in columns:
            tree.heading(col, text=col)
            tree.column(col, width=100)
        
        for resource in resources:
            status = 'Available' if resource['is_available'] else '❌ Booked'
            tree.insert('', 'end', values=(
                resource['resource_id'],
                resource['resource_name'],
                resource['resource_type'],
                resource['capacity'],
                status
            ))
        
        tree.pack(fill='both', expand=True, padx=20, pady=10)
        
        tk.Label(self.content_panel, text="📋 Recent Bookings", font=('Helvetica', 14, 'bold'),
                fg='#2c3e50', bg='white').pack(pady=(20, 10))
        
        if bookings:
            recent = bookings[:10]
            columns2 = ('Resource', 'User', 'Date', 'Time', 'Status')
            tree2 = ttk.Treeview(self.content_panel, columns=columns2, show='headings', height=5)
            
            for col in columns2:
                tree2.heading(col, text=col)
                tree2.column(col, width=100)
            
            for booking in recent:
                status = ' Active' if booking['status'] == 'active' else '❌ Cancelled'
                tree2.insert('', 'end', values=(
                    booking['resource_name'],
                    booking['username'],
                    booking['booking_date'],
                    booking['start_time'],
                    status
                ))
            
            tree2.pack(fill='both', expand=True, padx=20, pady=10)
        else:
            tk.Label(self.content_panel, text="No bookings recorded.", 
                    font=('Helvetica', 12), fg='#7f8c8d', bg='white').pack(pady=10)
        
        tk.Button(self.content_panel, text="Back to Menu", font=('Helvetica', 12),
                 bg='#7f8c8d', fg='white', padx=20, pady=8,
                 command=self._refresh_menu).pack(pady=10)
    
    def _generate_report(self):
        """Generate campus report (Admin only)."""
        if not self.current_campus:
            messagebox.showwarning("No Campus", "Please select a campus first.")
            return
        
        report = self.db.get_campus_report(self.current_campus)
        
        self._clear_content()
        
        tk.Label(self.content_panel, text=f" Campus Report - {self.current_campus}", 
                font=('Helvetica', 16, 'bold'), fg='#2c3e50', bg='white').pack(pady=20)
        
        report_frame = tk.Frame(self.content_panel, bg='white', relief='groove', bd=2)
        report_frame.pack(pady=20, padx=40, fill='x')
        
        tk.Label(report_frame, text=f" Total Bookings: {report['total_bookings']}", 
                font=('Helvetica', 14), bg='white').pack(pady=10, anchor='w', padx=20)
        
        tk.Label(report_frame, text=f" Average Booking Duration: {report['average_booking_duration']} hours", 
                font=('Helvetica', 14), bg='white').pack(pady=10, anchor='w', padx=20)
        
        tk.Label(report_frame, text=" Most Frequently Used Resources:", 
                font=('Helvetica', 14, 'bold'), bg='white').pack(pady=(10, 5), anchor='w', padx=20)
        
        if report['most_used_resources']:
            for resource in report['most_used_resources']:
                tk.Label(report_frame, text=f"  - {resource['name']}: {resource['count']} bookings", 
                        font=('Helvetica', 12), bg='white').pack(anchor='w', padx=40, pady=2)
        else:
            tk.Label(report_frame, text="  No booking data available.", 
                    font=('Helvetica', 12), fg='#7f8c8d', bg='white').pack(anchor='w', padx=40, pady=5)
        
        policy = get_booking_policy(self.current_campus)
        tk.Label(report_frame, text=f" Booking Policy: {policy.get_policy_description()}", 
                font=('Helvetica', 12), fg='#f39c12', bg='white').pack(pady=10, anchor='w', padx=20)
        
        tk.Button(self.content_panel, text="Back to Menu", font=('Helvetica', 12),
                 bg='#7f8c8d', fg='white', padx=20, pady=8,
                 command=self._refresh_menu).pack(pady=10)
    
    #  OPERATOR METHODS 
    
    def _view_campuses(self):
        """View all campuses (Operator only)."""
        campuses = self.db.get_all_campuses()
        self._clear_content()
        
        tk.Label(self.content_panel, text=" All Campuses", 
                font=('Helvetica', 16, 'bold'), fg='#2c3e50', bg='white').pack(pady=20)
        
        if not campuses:
            tk.Label(self.content_panel, text="No campuses found.", 
                    font=('Helvetica', 12), fg='#7f8c8d', bg='white').pack(pady=20)
            return
        
        columns = ('Name', 'Location', 'Max Duration', 'Hours', 'Priority')
        tree = ttk.Treeview(self.content_panel, columns=columns, show='headings', height=10)
        
        for col in columns:
            tree.heading(col, text=col)
            tree.column(col, width=120)
        
        for campus in campuses:
            hours = f"{campus['restricted_hours_start']} - {campus['restricted_hours_end']}"
            tree.insert('', 'end', values=(
                campus['name'],
                campus['location'],
                f"{campus['max_booking_duration']}h",
                hours,
                campus['priority_access']
            ))
        
        tree.pack(fill='both', expand=True, padx=20, pady=10)
        
        tk.Button(self.content_panel, text="Back to Menu", font=('Helvetica', 12),
                 bg='#7f8c8d', fg='white', padx=20, pady=8,
                 command=self._refresh_menu).pack(pady=10)
    
    def _view_all_resources(self):
        """View all resources across all campuses (Operator only)."""
        campuses = self.db.get_all_campuses()
        self._clear_content()
        
        tk.Label(self.content_panel, text=" All Resources (Cross-Campus)", 
                font=('Helvetica', 16, 'bold'), fg='#2c3e50', bg='white').pack(pady=20)
        
        if not campuses:
            tk.Label(self.content_panel, text="No campuses found.", 
                    font=('Helvetica', 12), fg='#7f8c8d', bg='white').pack(pady=20)
            return
        
        notebook = ttk.Notebook(self.content_panel)
        notebook.pack(fill='both', expand=True, padx=20, pady=10)
        
        for campus in campuses:
            campus_name = campus['name']
            resources = self.db.get_resources_by_campus(campus_name)
            
            tab = tk.Frame(notebook, bg='white')
            notebook.add(tab, text=campus_name)
            
            if resources:
                columns = ('ID', 'Name', 'Type', 'Capacity', 'Available')
                tree = ttk.Treeview(tab, columns=columns, show='headings', height=8)
                
                for col in columns:
                    tree.heading(col, text=col)
                    tree.column(col, width=100)
                
                for resource in resources:
                    status = ' Available' if resource['is_available'] else ' Booked'
                    tree.insert('', 'end', values=(
                        resource['resource_id'],
                        resource['resource_name'],
                        resource['resource_type'],
                        resource['capacity'],
                        status
                    ))
                
                tree.pack(fill='both', expand=True, padx=10, pady=10)
            else:
                tk.Label(tab, text="No resources available for this campus.", 
                        font=('Helvetica', 12), fg='#7f8c8d', bg='white').pack(pady=30)
        
        tk.Button(self.content_panel, text="Back to Menu", font=('Helvetica', 12),
                 bg='#7f8c8d', fg='white', padx=20, pady=8,
                 command=self._refresh_menu).pack(pady=10)
    
    def _view_all_bookings(self):
        """View all bookings across all campuses (Operator only)."""
        bookings = self.db.get_all_bookings()
        self._clear_content()
        
        tk.Label(self.content_panel, text=" All Bookings (System-Wide)", 
                font=('Helvetica', 16, 'bold'), fg='#2c3e50', bg='white').pack(pady=20)
        
        if not bookings:
            tk.Label(self.content_panel, text="No bookings found.", 
                    font=('Helvetica', 12), fg='#7f8c8d', bg='white').pack(pady=20)
            return
        
        columns = ('ID', 'Resource', 'User', 'Campus', 'Date', 'Time', 'Status')
        tree = ttk.Treeview(self.content_panel, columns=columns, show='headings', height=15)
        
        for col in columns:
            tree.heading(col, text=col)
            tree.column(col, width=100)
        
        for booking in bookings:
            status = ' Active' if booking['status'] == 'active' else ' Cancelled'
            tree.insert('', 'end', values=(
                booking['booking_id'],
                booking['resource_name'],
                booking['username'],
                booking['campus_name'],
                booking['booking_date'],
                booking['start_time'],
                status
            ))
        
        tree.pack(fill='both', expand=True, padx=20, pady=10)
        
        tk.Button(self.content_panel, text="Back to Menu", font=('Helvetica', 12),
                 bg='#7f8c8d', fg='white', padx=20, pady=8,
                 command=self._refresh_menu).pack(pady=10)
    
    def _cross_campus_report(self):
        """Generate cross-campus comparative report (Operator only)."""
        campuses = self.db.get_all_campuses()
        self._clear_content()
        
        tk.Label(self.content_panel, text=" Cross-Campus Comparative Report", 
                font=('Helvetica', 16, 'bold'), fg='#2c3e50', bg='white').pack(pady=20)
        
        if not campuses:
            tk.Label(self.content_panel, text="No campuses found.", 
                    font=('Helvetica', 12), fg='#7f8c8d', bg='white').pack(pady=20)
            return
        
        columns = ('Campus', 'Total Bookings', 'Avg Duration', 'Most Used Resource', 'Policy')
        tree = ttk.Treeview(self.content_panel, columns=columns, show='headings', height=10)
        
        for col in columns:
            tree.heading(col, text=col)
            tree.column(col, width=140)
        
        for campus in campuses:
            report = self.db.get_campus_report(campus['name'])
            policy = get_booking_policy(campus['name'])
            most_used = report['most_used_resources'][0]['name'] if report['most_used_resources'] else 'N/A'
            
            tree.insert('', 'end', values=(
                campus['name'],
                report['total_bookings'],
                f"{report['average_booking_duration']}h",
                most_used,
                policy.get_policy_description()
            ))
        
        tree.pack(fill='both', expand=True, padx=20, pady=10)
        
        tk.Button(self.content_panel, text="Back to Menu", font=('Helvetica', 12),
                 bg='#7f8c8d', fg='white', padx=20, pady=8,
                 command=self._refresh_menu).pack(pady=10)
    
    def _add_campus(self):
        """Add a new campus (Operator only)."""
        self._clear_content()
        
        tk.Label(self.content_panel, text=" Add New Campus", 
                font=('Helvetica', 16, 'bold'), fg='#2c3e50', bg='white').pack(pady=20)
        
        form_frame = tk.Frame(self.content_panel, bg='white')
        form_frame.pack(pady=20, padx=40)
        
        tk.Label(form_frame, text="Campus Name:", font=('Helvetica', 12), 
                bg='white').grid(row=0, column=0, padx=10, pady=10, sticky='w')
        self.add_campus_name = tk.Entry(form_frame, font=('Helvetica', 12), width=30)
        self.add_campus_name.grid(row=0, column=1, padx=10, pady=10)
        
        tk.Label(form_frame, text="Location:", font=('Helvetica', 12), 
                bg='white').grid(row=1, column=0, padx=10, pady=10, sticky='w')
        self.add_campus_location = tk.Entry(form_frame, font=('Helvetica', 12), width=30)
        self.add_campus_location.grid(row=1, column=1, padx=10, pady=10)
        
        tk.Label(form_frame, text="Max Duration (hours):", font=('Helvetica', 12), 
                bg='white').grid(row=2, column=0, padx=10, pady=10, sticky='w')
        self.add_campus_duration = tk.Spinbox(form_frame, from_=1, to=8,
                                             font=('Helvetica', 12), width=10)
        self.add_campus_duration.grid(row=2, column=1, padx=10, pady=10, sticky='w')
        self.add_campus_duration.delete(0, 'end')
        self.add_campus_duration.insert(0, '4')
        
        tk.Label(form_frame, text="Restricted Start:", font=('Helvetica', 12), 
                bg='white').grid(row=3, column=0, padx=10, pady=10, sticky='w')
        self.add_campus_start = ttk.Combobox(form_frame, 
                                            values=[f"{h:02d}:00" for h in range(6, 12)],
                                            font=('Helvetica', 12), width=28)
        self.add_campus_start.grid(row=3, column=1, padx=10, pady=10)
        self.add_campus_start.set('08:00')
        
        tk.Label(form_frame, text="Restricted End:", font=('Helvetica', 12), 
                bg='white').grid(row=4, column=0, padx=10, pady=10, sticky='w')
        self.add_campus_end = ttk.Combobox(form_frame, 
                                          values=[f"{h:02d}:00" for h in range(17, 24)],
                                          font=('Helvetica', 12), width=28)
        self.add_campus_end.grid(row=4, column=1, padx=10, pady=10)
        self.add_campus_end.set('18:00')
        
        def submit_campus():
            name = self.add_campus_name.get().strip()
            location = self.add_campus_location.get().strip()
            duration = int(self.add_campus_duration.get())
            start = self.add_campus_start.get()
            end = self.add_campus_end.get()
            
            if not name:
                messagebox.showerror("Error", "Campus name is required.")
                return
            
            success = self.db.add_campus(name, location, duration, start, end, 'lecturers')
            
            if success:
                messagebox.showinfo("Success", f" Campus '{name}' added successfully!")
                self._refresh_menu()
            else:
                messagebox.showerror("Error", "Campus already exists.")
        
        tk.Button(self.content_panel, text="Add Campus", font=('Helvetica', 14, 'bold'),
                 bg='#27ae60', fg='white', padx=40, pady=10,
                 command=submit_campus).pack(pady=20)
        
        tk.Button(self.content_panel, text="Back to Menu", font=('Helvetica', 12),
                 bg='#7f8c8d', fg='white', padx=20, pady=8,
                 command=self._refresh_menu).pack(pady=10)
    
    def _clear_content(self):
        """Clear the content panel."""
        if hasattr(self, 'content_panel'):
            for widget in self.content_panel.winfo_children():
                widget.destroy()
    
    def _view_bookings(self):
        """Legacy method - redirects to active bookings."""
        self._view_active_bookings()