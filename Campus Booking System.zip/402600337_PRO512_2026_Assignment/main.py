"""
Entry point for the Smart Campus Resource Booking System.
"""

from app import SmartCampusBookingApp


if __name__ == "__main__":
    print("=" * 50)
    print("Smart Campus Resource Booking System")
    print("Richfield Graduate Institution")
    print("Starting application...")
    print("=" * 50)
    app = SmartCampusBookingApp()