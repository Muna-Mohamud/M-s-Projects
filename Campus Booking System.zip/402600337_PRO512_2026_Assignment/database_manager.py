
import sqlite3
import datetime
import time


class DatabaseManager:
    """
    Handles all database operations for the Smart Campus Resource Booking System.
    
    """
    
    def __init__(self, db_name="campus_booking.db"):
        self.db_name = db_name
        self._create_tables()
        self._create_indexes()
    
    def _get_connection(self):
        """Establish connection to the SQLite database."""
        return sqlite3.connect(self.db_name)
    
    def _create_tables(self):
        """
        Create all necessary tables if they don't exist.
        
        Tables:
            - users: Stores user credentials and roles
            - campuses: Campus configuration and policies
            - resources: Available resources per campus
            - bookings: All booking records
            - booking_rules: Extensible rules framework
        """
        conn = self._get_connection()
        cursor = conn.cursor()
        
        # Users table - stores authentication and role information
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                user_id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password TEXT NOT NULL,
                role TEXT NOT NULL,
                campus_name TEXT,
                full_name TEXT,
                email TEXT
            )
        ''')
        
        # Campuses table - stores campus configuration and policies
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS campuses (
                campus_id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT UNIQUE NOT NULL,
                location TEXT,
                max_booking_duration INTEGER DEFAULT 4,
                restricted_hours_start TEXT DEFAULT '08:00',
                restricted_hours_end TEXT DEFAULT '18:00',
                priority_access TEXT DEFAULT 'lecturers'
            )
        ''')
        
        # Resources table - stores all bookable resources
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS resources (
                resource_id INTEGER PRIMARY KEY AUTOINCREMENT,
                resource_name TEXT NOT NULL,
                resource_type TEXT NOT NULL,
                campus_name TEXT NOT NULL,
                capacity INTEGER DEFAULT 1,
                is_available INTEGER DEFAULT 1,
                unique_identifier TEXT UNIQUE NOT NULL,
                FOREIGN KEY (campus_name) REFERENCES campuses(name)
            )
        ''')
        
        # Bookings table - stores all booking records
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS bookings (
                booking_id INTEGER PRIMARY KEY AUTOINCREMENT,
                resource_id INTEGER NOT NULL,
                username TEXT NOT NULL,
                campus_name TEXT NOT NULL,
                booking_date TEXT NOT NULL,
                start_time TEXT NOT NULL,
                duration INTEGER NOT NULL,
                end_time TEXT NOT NULL,
                status TEXT DEFAULT 'active',
                created_at INTEGER DEFAULT 0,
                FOREIGN KEY (resource_id) REFERENCES resources(resource_id),
                FOREIGN KEY (username) REFERENCES users(username)
            )
        ''')
        
        # Booking rules table - extensible rules framework
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS booking_rules (
                rule_id INTEGER PRIMARY KEY AUTOINCREMENT,
                campus_name TEXT NOT NULL,
                rule_name TEXT NOT NULL,
                rule_value TEXT NOT NULL,
                FOREIGN KEY (campus_name) REFERENCES campuses(name)
            )
        ''')
        
        conn.commit()
        conn.close()
    
    def _create_indexes(self):
        """Create indexes for better query performance."""
        conn = self._get_connection()
        cursor = conn.cursor()
        
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_bookings_resource_date ON bookings(resource_id, booking_date)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_bookings_username ON bookings(username)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_bookings_campus ON bookings(campus_name)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_resources_campus ON resources(campus_name)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_users_username ON users(username)')
        
        conn.commit()
        conn.close()
    
    # USER OPERATIONS 
    
    def register_user(self, username, password, role, campus_name="", full_name="", email=""):
        """Register a new user in the system."""
        if role in ['lecturer', 'admin'] and campus_name:
            campus = self.get_campus_by_name(campus_name)
            if not campus:
                return False, "Campus does not exist."
        
        try:
            conn = self._get_connection()
            cursor = conn.cursor()
            
            cursor.execute('''
                INSERT INTO users (username, password, role, campus_name, full_name, email)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (username, password, role, campus_name, full_name, email))
            
            conn.commit()
            conn.close()
            return True, "Registration successful."
        except sqlite3.IntegrityError:
            return False, "Username already exists."
    
    def authenticate_user(self, username, password):
        """Authenticate user login credentials."""
        conn = self._get_connection()
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT username, role, campus_name, full_name, email
            FROM users
            WHERE username = ? AND password = ?
        ''', (username, password))
        
        result = cursor.fetchone()
        conn.close()
        
        if result:
            return {
                'username': result[0],
                'role': result[1],
                'campus_name': result[2],
                'full_name': result[3],
                'email': result[4]
            }
        return None
    
    def get_user_by_username(self, username):
        """Retrieve user information by username."""
        conn = self._get_connection()
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT username, role, campus_name, full_name, email
            FROM users
            WHERE username = ?
        ''', (username,))
        
        result = cursor.fetchone()
        conn.close()
        
        if result:
            return {
                'username': result[0],
                'role': result[1],
                'campus_name': result[2],
                'full_name': result[3],
                'email': result[4]
            }
        return None
    
    #  CAMPUS OPERATIONS 
    
    def get_all_campuses(self):
        """Retrieve all campuses from the database."""
        conn = self._get_connection()
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT name, location, max_booking_duration, 
                   restricted_hours_start, restricted_hours_end, priority_access
            FROM campuses
        ''')
        
        results = cursor.fetchall()
        conn.close()
        
        campuses = []
        for row in results:
            campuses.append({
                'name': row[0],
                'location': row[1] or "",
                'max_booking_duration': row[2],
                'restricted_hours_start': row[3],
                'restricted_hours_end': row[4],
                'priority_access': row[5]
            })
        return campuses
    
    def get_campus_by_name(self, name):
        """Retrieve a specific campus by name."""
        conn = self._get_connection()
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT name, location, max_booking_duration, 
                   restricted_hours_start, restricted_hours_end, priority_access
            FROM campuses
            WHERE name = ?
        ''', (name,))
        
        result = cursor.fetchone()
        conn.close()
        
        if result:
            return {
                'name': result[0],
                'location': result[1] or "",
                'max_booking_duration': result[2],
                'restricted_hours_start': result[3],
                'restricted_hours_end': result[4],
                'priority_access': result[5]
            }
        return None
    
    def add_campus(self, name, location="", max_duration=4,
                   restricted_start="08:00", restricted_end="18:00",
                   priority="lecturers"):
        """Add a new campus to the system."""
        try:
            conn = self._get_connection()
            cursor = conn.cursor()
            
            cursor.execute('''
                INSERT INTO campuses (name, location, max_booking_duration, 
                                     restricted_hours_start, restricted_hours_end, priority_access)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (name, location, max_duration, restricted_start, restricted_end, priority))
            
            conn.commit()
            conn.close()
            return True
        except sqlite3.IntegrityError:
            return False
    
    #  RESOURCE OPERATIONS 
    
    def add_resource(self, resource_name, resource_type, campus_name,
                     capacity=1, is_available=True):
        """Add a new resource to a campus with a unique identifier."""
        unique_id = f"{campus_name}_{resource_name}_{resource_type}_{capacity}_{int(time.time())}"
        
        try:
            conn = self._get_connection()
            cursor = conn.cursor()
            
            cursor.execute('''
                INSERT INTO resources (resource_name, resource_type, campus_name, 
                                      capacity, is_available, unique_identifier)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (resource_name, resource_type, campus_name, capacity, 
                  1 if is_available else 0, unique_id))
            
            conn.commit()
            conn.close()
            return True
        except sqlite3.IntegrityError:
            return False
    
    def get_resources_by_campus(self, campus_name):
        """Retrieve all resources for a specific campus."""
        conn = self._get_connection()
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT resource_id, resource_name, resource_type, campus_name, 
                   capacity, is_available, unique_identifier
            FROM resources
            WHERE campus_name = ?
            ORDER BY resource_name
        ''', (campus_name,))
        
        results = cursor.fetchall()
        conn.close()
        
        resources = []
        for row in results:
            resources.append({
                'resource_id': row[0],
                'resource_name': row[1],
                'resource_type': row[2],
                'campus_name': row[3],
                'capacity': row[4],
                'is_available': bool(row[5]),
                'unique_identifier': row[6]
            })
        return resources
    
    def update_resource_availability(self, resource_id, is_available):
        """Update the availability status of a resource."""
        try:
            conn = self._get_connection()
            cursor = conn.cursor()
            
            cursor.execute('''
                UPDATE resources
                SET is_available = ?
                WHERE resource_id = ?
            ''', (1 if is_available else 0, resource_id))
            
            conn.commit()
            conn.close()
            return True
        except Exception:
            return False
    
    def delete_resource(self, resource_id):
        """Delete a resource from the system."""
        try:
            conn = self._get_connection()
            cursor = conn.cursor()
            
            cursor.execute('DELETE FROM resources WHERE resource_id = ?', (resource_id,))
            
            conn.commit()
            conn.close()
            return True
        except Exception:
            return False
    
    #  BOOKING OPERATIONS 
    
    def create_booking(self, resource_id, username, campus_name,
                       booking_date, start_time, duration):
        """
        Create a new booking with overlap prevention.
        
        Returns:
            bool: True if booking successful, False if conflict occurs
        """
        start_hour, start_min = map(int, start_time.split(':'))
        end_hour = start_hour + duration
        end_time = f"{end_hour:02d}:{start_min:02d}"
        
        conn = self._get_connection()
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT COUNT(*)
            FROM bookings
            WHERE resource_id = ? 
            AND booking_date = ?
            AND status = 'active'
            AND (
                (start_time <= ? AND end_time > ?) OR
                (start_time < ? AND end_time >= ?) OR
                (start_time >= ? AND start_time < ?)
            )
        ''', (resource_id, booking_date, start_time, start_time, end_time, end_time, 
              start_time, end_time))
        
        count = cursor.fetchone()[0]
        
        if count > 0:
            conn.close()
            return False, "Resource already booked for this time slot."
        
        created_at = int(time.time())
        cursor.execute('''
            INSERT INTO bookings (resource_id, username, campus_name, 
                                 booking_date, start_time, duration, end_time, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ''', (resource_id, username, campus_name, booking_date, start_time, duration, end_time, created_at))
        
        conn.commit()
        conn.close()
        return True, "Booking created successfully."
    
    def get_bookings_by_username(self, username):
        """Retrieve all bookings for a specific user."""
        conn = self._get_connection()
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT b.booking_id, b.resource_id, r.resource_name, r.resource_type,
                   b.campus_name, b.booking_date, b.start_time, b.duration, b.end_time, b.status
            FROM bookings b
            JOIN resources r ON b.resource_id = r.resource_id
            WHERE b.username = ?
            ORDER BY b.booking_date DESC, b.start_time DESC
        ''', (username,))
        
        results = cursor.fetchall()
        conn.close()
        
        bookings = []
        for row in results:
            bookings.append({
                'booking_id': row[0],
                'resource_id': row[1],
                'resource_name': row[2],
                'resource_type': row[3],
                'campus_name': row[4],
                'booking_date': row[5],
                'start_time': row[6],
                'duration': row[7],
                'end_time': row[8],
                'status': row[9]
            })
        return bookings
    
    def get_active_bookings_by_username(self, username):
        """Retrieve only active (future) bookings for a specific user."""
        conn = self._get_connection()
        cursor = conn.cursor()
        
        today = datetime.date.today().strftime('%Y-%m-%d')
        current_time = datetime.datetime.now().strftime('%H:%M')
        
        cursor.execute('''
            SELECT b.booking_id, b.resource_id, r.resource_name, r.resource_type,
                   b.campus_name, b.booking_date, b.start_time, b.duration, b.end_time, b.status
            FROM bookings b
            JOIN resources r ON b.resource_id = r.resource_id
            WHERE b.username = ?
            AND b.status = 'active'
            AND (b.booking_date > ? OR (b.booking_date = ? AND b.start_time > ?))
            ORDER BY b.booking_date ASC, b.start_time ASC
        ''', (username, today, today, current_time))
        
        results = cursor.fetchall()
        conn.close()
        
        bookings = []
        for row in results:
            bookings.append({
                'booking_id': row[0],
                'resource_id': row[1],
                'resource_name': row[2],
                'resource_type': row[3],
                'campus_name': row[4],
                'booking_date': row[5],
                'start_time': row[6],
                'duration': row[7],
                'end_time': row[8],
                'status': row[9]
            })
        return bookings
    
    def get_past_bookings_by_username(self, username):
        """Retrieve past bookings for a specific user."""
        conn = self._get_connection()
        cursor = conn.cursor()
        
        today = datetime.date.today().strftime('%Y-%m-%d')
        current_time = datetime.datetime.now().strftime('%H:%M')
        
        cursor.execute('''
            SELECT b.booking_id, b.resource_id, r.resource_name, r.resource_type,
                   b.campus_name, b.booking_date, b.start_time, b.duration, b.end_time, b.status
            FROM bookings b
            JOIN resources r ON b.resource_id = r.resource_id
            WHERE b.username = ?
            AND (b.booking_date < ? OR (b.booking_date = ? AND b.start_time <= ?) OR b.status = 'cancelled')
            ORDER BY b.booking_date DESC, b.start_time DESC
        ''', (username, today, today, current_time))
        
        results = cursor.fetchall()
        conn.close()
        
        bookings = []
        for row in results:
            bookings.append({
                'booking_id': row[0],
                'resource_id': row[1],
                'resource_name': row[2],
                'resource_type': row[3],
                'campus_name': row[4],
                'booking_date': row[5],
                'start_time': row[6],
                'duration': row[7],
                'end_time': row[8],
                'status': row[9]
            })
        return bookings
    
    def get_bookings_by_campus(self, campus_name):
        """Retrieve all bookings for a specific campus."""
        conn = self._get_connection()
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT b.booking_id, b.resource_id, r.resource_name, b.username,
                   b.booking_date, b.start_time, b.duration, b.end_time, b.status
            FROM bookings b
            JOIN resources r ON b.resource_id = r.resource_id
            WHERE b.campus_name = ?
            ORDER BY b.booking_date DESC, b.start_time DESC
        ''', (campus_name,))
        
        results = cursor.fetchall()
        conn.close()
        
        bookings = []
        for row in results:
            bookings.append({
                'booking_id': row[0],
                'resource_id': row[1],
                'resource_name': row[2],
                'username': row[3],
                'booking_date': row[4],
                'start_time': row[5],
                'duration': row[6],
                'end_time': row[7],
                'status': row[8]
            })
        return bookings
    
    def get_all_bookings(self):
        """Retrieve all bookings from the system."""
        conn = self._get_connection()
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT b.booking_id, b.resource_id, r.resource_name, b.username,
                   b.campus_name, b.booking_date, b.start_time, b.duration, b.end_time, b.status
            FROM bookings b
            JOIN resources r ON b.resource_id = r.resource_id
            ORDER BY b.booking_date DESC, b.start_time DESC
        ''')
        
        results = cursor.fetchall()
        conn.close()
        
        bookings = []
        for row in results:
            bookings.append({
                'booking_id': row[0],
                'resource_id': row[1],
                'resource_name': row[2],
                'username': row[3],
                'campus_name': row[4],
                'booking_date': row[5],
                'start_time': row[6],
                'duration': row[7],
                'end_time': row[8],
                'status': row[9]
            })
        return bookings
    
    def cancel_booking(self, booking_id):
        """Cancel an existing booking."""
        try:
            conn = self._get_connection()
            cursor = conn.cursor()
            
            cursor.execute('''
                UPDATE bookings
                SET status = 'cancelled'
                WHERE booking_id = ? AND status = 'active'
            ''', (booking_id,))
            
            conn.commit()
            conn.close()
            return True
        except Exception:
            return False
    
    # ========== REPORTING OPERATIONS ==========
    
    def get_campus_report(self, campus_name):
        """
        Generate a comprehensive report for a specific campus.
        
        Returns:
            dict: Contains total bookings, most used resources, average duration
        """
        conn = self._get_connection()
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT COUNT(*)
            FROM bookings
            WHERE campus_name = ? AND status = 'active'
        ''', (campus_name,))
        total_bookings = cursor.fetchone()[0] or 0
        
        cursor.execute('''
            SELECT r.resource_name, COUNT(b.booking_id) as usage_count
            FROM bookings b
            JOIN resources r ON b.resource_id = r.resource_id
            WHERE b.campus_name = ? AND b.status = 'active'
            GROUP BY r.resource_name
            ORDER BY usage_count DESC
            LIMIT 5
        ''', (campus_name,))
        most_used = cursor.fetchall()
        
        cursor.execute('''
            SELECT AVG(duration)
            FROM bookings
            WHERE campus_name = ? AND status = 'active'
        ''', (campus_name,))
        avg_duration = cursor.fetchone()[0] or 0
        
        conn.close()
        
        return {
            'campus_name': campus_name,
            'total_bookings': total_bookings,
            'most_used_resources': [{'name': row[0], 'count': row[1]} for row in most_used],
            'average_booking_duration': round(avg_duration, 2)
        }