"""
User models for the Smart Campus Resource Booking System.

"""

from abc import ABC, abstractmethod
from database_manager import DatabaseManager


class User(ABC):
    """
    Abstract base class for all user types.
    
    """
    
    def __init__(self, username, password, campus_name=""):
        self._username = username
        self._password = password
        self._campus_name = campus_name
        self._db = DatabaseManager()
    
    @abstractmethod
    def get_menu_items(self):
        """Return the menu items available for this user role."""
        pass
    
    @abstractmethod
    def get_role_name(self):
        """Return the name of the user role."""
        pass


class Lecturer(User):
   
    
    def __init__(self, username, password, campus_name=""):
        super().__init__(username, password, campus_name)
        self._role = "lecturer"
    
    def get_menu_items(self):
        """Return lecturer menu items."""
        return [
            ("View Available Resources", "view_resources"),
            ("Create Booking", "create_booking"),
            ("View Active Bookings", "view_active_bookings"),
            ("View Past Bookings", "view_past_bookings"),
            ("Cancel Booking", "cancel_booking"),
            ("Logout", "logout")
        ]
    
    def get_role_name(self):
        return "Lecturer"


class CampusAdministrator(User):
 
    def __init__(self, username, password, campus_name=""):
        super().__init__(username, password, campus_name)
        self._role = "admin"
    
    def get_menu_items(self):
        """Return campus administrator menu items."""
        return [
            ("Add Resource", "add_resource"),
            ("Update Resource", "update_resource"),
            ("Remove Resource", "remove_resource"),
            ("View Campus Bookings", "view_campus_bookings"),
            ("Monitor Resource Availability", "monitor_availability"),
            ("Generate Campus Report", "generate_report"),
            ("Logout", "logout")
        ]
    
    def get_role_name(self):
        return "Campus Administrator"


class SystemOperator(User):
  
    
    def __init__(self, username, password, campus_name=""):
        super().__init__(username, password, campus_name)
        self._role = "operator"
    
    def get_menu_items(self):
        """Return system operator menu items."""
        return [
            ("View All Campuses", "view_campuses"),
            ("View All Resources", "view_all_resources"),
            ("View All Bookings", "view_all_bookings"),
            ("Generate Cross-Campus Report", "cross_campus_report"),
            ("Add New Campus", "add_campus"),
            ("Logout", "logout")
        ]
    
    def get_role_name(self):
        return "System Operator"


def get_user_object(role, username, password, campus_name=""):
    """Factory function to create the appropriate user object."""
    if role == 'lecturer':
        return Lecturer(username, password, campus_name)
    elif role == 'admin':
        return CampusAdministrator(username, password, campus_name)
    elif role == 'operator':
        return SystemOperator(username, password, campus_name)
    else:
        return Lecturer(username, password, campus_name)