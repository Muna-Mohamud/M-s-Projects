import time
import os

                         # This creates extra files incase the system doesnt have it in the folder
def file_creation():
    if not os.path.exists("user_data.txt"):
        open("user_data.txt", "w").close()
    if not os.path.exists("parking.txt"):
        open("parking.txt", "w").close()
    if not os.path.exists("payments.txt"):
        open("payments.txt", "w").close()


            ###################################### LOGIN AND REGISTRATION DETAILS START########################################
                                    #<---This registers a users account if they pick option one
def register():
    username = input("Enter username: ").strip()
    password = input("Enter password: ").strip()
    role = input("Enter role (customer/admin/owner): ").strip().lower()

    if username == "" or password == "":
        print("Username and password cannot be empty.")
        return

    if role != "customer" and role != "admin" and role != "owner":
        print("Invalid role.")  #<--- first if statement prevents duplicate username and this makes sure they only type one of the three
        return

                                #this basically reads the user data to make sure there are no repeated usernames
    file = open("user_data.txt", "r")
    for line in file:
        data = line.strip().split(",")
        if len(data) >= 1 and data[0] == username:
            print("Username already exists.Try again.")
            file.close()
            return
    file.close()

                        # Assign a mall for admin if the user logged in and picked admin
    assigned_mall = ""
    if role == "admin":
        print("\nAssign mall to admin:")
        print("1 - Gateway")
        print("2 - Pavilion")
        print("3 - LaLucia")
        choice = input("Choice: ")
        if choice == "1":
            assigned_mall = "Gateway"
        elif choice == "2":
            assigned_mall = "Pavilion"
        elif choice == "3":
            assigned_mall = "LaLucia"
        else:
            print("Invalid mall selection.")
            return

    # Save user
    file = open("user_data.txt", "a")
    file.write(username + "," + password + "," + role + "," + assigned_mall + "\n")
    file.close()
    print("Registration successful!")

# LOGIN
def login():
    username = input("Username: ").strip()
    password = input("Password: ").strip()

    if username == "" or password == "":
        print("Invalid login details.")
        return "", "", ""

    file = open("user_data.txt", "r")
    for line in file:
        data = line.strip().split(",")
        if len(data) >= 4:
            if data[0] == username and data[1] == password:
                file.close()
                return username, data[2], data[3]
    file.close()
    print("Invalid login details.")
    return "", "", ""

                    ###################################### LOGIN AND REGISTRATION DETAILS END########################################

                     #<----The functions i use to calculate the prices
def Gateway():
    return 15

def Pavillion(hours):
    return hours * 10

def lalucia(hours):
    amount = hours * 12
    return min(amount, 60)


                            # <---The customer mall selection. Placed lower and not in the reg function because customers can freely change their mall choice unlike admin
def mall_choice():
    print("\nSelect Mall:")
    print("1 - Gateway (Flat Rate R15, Capacity 250)")
    print("2 - Pavilion (R10/hour, Capacity 180)")
    print("3 - LaLucia (R12/hour capped at R60, Capacity 150)")
    
    choice = input("Choice: ")
    if choice == "1":
        return "Gateway", 250
    elif choice == "2":
        return "Pavilion", 180
    elif choice == "3":
        return "LaLucia", 150
    else:
        print("Invalid selection.")
        return "", 0
            ######################################  Vehicle entry and exit(its important, mostly for customer menu)########################################
                # counts how many cars are in the system.Initially starts with 0 but if file reading picks up someone in the txt file the count adds one
def count_current_vehicles(mall):
    count = 0
    try:
        file = open("parking.txt", "r")
        for line in file:
            data = line.strip().split(",")
            if len(data) >= 4 and data[1] == mall and data[3] == "0":
                count += 1
        file.close()
    except:
        pass
    return count

                                                        # USER VEHICLE ENTRY
def vehicle_entry(username, mall, capacity):
                                                             # <---Prevent duplicate parking with cars that already entered.
    try:
        file = open("parking.txt", "r")
        for line in file:
            data = line.strip().split(",")
            if len(data) >= 4:
                if data[0] == username and data[1] == mall and data[3] == "0":
                    print("You vehicle has already entered and did not exit yet.")
                    file.close()
                    return
        file.close()
    except:
        pass

    current = count_current_vehicles(mall)

    if current >= capacity:
        print("Parking full. Entry denied.")
        return

    vehicle_entry = int(time.time())
    file = open("parking.txt", "a")
    file.write(username + "," + mall + "," + str(vehicle_entry) + ",0,0\n")
    file.close()

    print("Vehicle entry recorded successfully.")

                                                            # ,--- USER VEHICLE EXIT
def vehicle_exit(username, mall):
    found = 0
    extra = open("extra.txt", "w") #creates a temporary file to update user data
    
    try:
        file = open("parking.txt", "r")
        for line in file:
            data = line.strip().split(",")
            
            if len(data) >= 5 and data[0] == username and data[1] == mall and data[3] == "0":
                found = 1 
                vehicle_entry = int(data[2])
                vehicle_exit = int(time.time())
                duration_seconds = vehicle_exit - vehicle_entry
                
                hours = duration_seconds // 3600
                if duration_seconds % 3600 != 0:
                    hours += 1
                if hours == 0:
                    hours = 1
                #<--- prices being charged when vehicle exits tho it gives the option to not pay
                if mall == "Gateway":
                    amount = Gateway()
                    pricing = "Flat Rate (R15)"
                elif mall == "Pavilion":
                    amount = Pavillion(hours)
                    pricing = "Hourly Rate (R10 per hour)"
                else:
                    amount = lalucia(hours)
                    pricing = "Hourly Rate with Cap (R12 per hour, max R60)"
                
                print("\nDuration (hours):", hours)
                print("Pricing Applied:", pricing)
                print("Amount Due: R", amount)
                
                pay = input("Confirm payment (yes/no): ").lower()
                
                if pay == "yes" or pay == "y" or pay == "Y":
                    payment_file = open("payments.txt", "a")
                    payment_file.write(username + "," + mall + "," + str(amount) + "\n")
                    payment_file.close()
                    data[4] = "1"
                    print("Payment made.")
                else:
                    print("Payment not made.")
                    data[4] = "0"
                
                extra.write(username + "," + mall + "," + data[2] + "," + str(vehicle_exit) + "," + data[4] + "\n")
            else:
                extra.write(line)
        file.close()
        extra.close()
    except Exception as e:
        print(f"Error: {e}")
        return
    
    os.remove("parking.txt")
    os.rename("extra.txt", "parking.txt")
    
                                 #if every vehicle left then it prints this statment
    if found == 0:
        print("No active parking record found.")

                            # Part of customer menu,<--- its the view history option
def parkingHistory(username):
    count = 0
    print("\n    --- Parking History ---")
    
    try:
        file = open("parking.txt", "r")
        for line in file:
            data = line.strip().split(",")
            if len(data) >= 5 and data[0] == username:
                count += 1
                vehicle_entered = time.ctime(int(data[2]))
                if data[3] == "0":
                    vehicle_exited = "Still Parked"
                else:
                    vehicle_exited = time.ctime(int(data[3]))
                status = "Paid" if data[4] == "1" else "Unpaid"
                print("\nMall:", data[1])
                print("Entry:", vehicle_entered)
                print("Exit:", vehicle_exited)
                print("Status:", status)
        file.close()
    except:
        pass
    
    if count == 0:
        print("No parking records found.")

                            # Function for customer to allow payment aka option nr4
def feePayment(username):
    extra = open("extra.txt", "w")
    
    try:
        file = open("parking.txt", "r")
        found = 0
        
        for line in file:
            data = line.strip().split(",")
            if len(data) >= 5 and data[0] == username and data[4] == "0" and data[3] != "0":
                found = 1
                vehicle_entry = int(data[2])
                vehicle_exit = int(data[3])
                duration_seconds = vehicle_exit - vehicle_entry
                
                hours = duration_seconds // 3600
                if duration_seconds % 3600 != 0:
                    hours += 1
                if hours == 0:
                    hours = 1
                
                mall = data[1]
                
                if mall == "Gateway":
                    amount = Gateway()
                elif mall == "Pavilion":
                    amount = Pavillion(hours)
                else:
                    amount = lalucia(hours)
                
                print("\nOutstanding Payment at", mall)
                print("Amount Due: R", amount)
                
                confirm = input("Confirm payment (yes/no): ").lower()
                        #giving the user all possible options because i cant retype yes manually again
                if confirm == "yes" or confirm == "Y" or confirm == "y":
                    payment_file = open("payments.txt", "a")
                    payment_file.write(username + "," + mall + "," + str(amount) + "\n")
                    payment_file.close()
                    data[4] = "1"
                    print("Payment successful!")
                else:
                    print("Payment not made.")
                
                extra.write(",".join(data) + "\n")
            else:
                extra.write(line)
        
        file.close()
        extra.close()
        
        os.remove("parking.txt")
        os.rename("extra.txt", "parking.txt")
        
        if found == 0:
            print("No outstanding payments found.")
    except Exception as e:
        print(f"Error: {e}")

                                            # <---Owner mall report
def mall_history(mall):
    total_vehicles = 0
    total_revenue = 0
    total_duration = 0
    
                                # this counts the vehicles and duration
    try:
        file = open("parking.txt", "r")
        for line in file:
            data = line.strip().split(",")
            if len(data) >= 5 and data[1] == mall and data[3] != "0":
                total_vehicles += 1
                vehicle_entry = int(data[2])
                vehicle_exit = int(data[3])
                total_duration += (vehicle_exit - vehicle_entry)
        file.close()
    except:
        pass
    
                            # this calculates the revenue from customer payments
    try:
        payment_file = open("payments.txt", "r")
        for line in payment_file:
            data = line.strip().split(",")
            if len(data) >= 3 and data[1] == mall:
                total_revenue += int(data[2])
        payment_file.close()
    except:
        pass
    
    if total_vehicles > 0:
        average_duration = (total_duration / total_vehicles) / 3600
    else:
        average_duration = 0
    
    print("\nMall:", mall)
    print("Total Vehicles:", total_vehicles)
    print("Total Revenue: R", total_revenue)
    print("Average Duration (hours):", round(average_duration, 2))

# OWNER / SHAREHOLDER REPORT
def owner_report():
    print("\n--- Gateway Theatre of Shopping ---")
    mall_history("Gateway")
    print("\n--- Pavilion Shopping Centre ---")
    mall_history("Pavilion")
    print("\n--- LaLucia Mall ---")
    mall_history("LaLucia")

# parkingSystem PROGRAM , The actual while function that calls every other function i made and put thems all together
def parkingSystem():
    file_creation()
    
    while True:
        print("---PARKING MANAGEMENT SYSTEM---")
        print("1 - Register")
        print("2 - Login")
        print("3 - Exit")
        
        choice = input("\nChoice: ")
        
        if choice == "1":
            register()
        
        elif choice == "2":
            user, role, assigned_mall = login()
            
            if user == "":
                continue
            
            if role == "customer":
                mall, capacity = mall_choice()
                if mall != "":
                    while True:
                        print(f"---Customer Menu - {mall}---")
                        print("1 - Vehicle Entry")
                        print("2 - Vehicle Exit")
                        print("3 - View History")
                        print("4 - Pay Outstanding")
                        print("5 - Logout")
                        
                        menu_choice = input("\nChoice: ")
                        
                        if menu_choice == "1":
                            vehicle_entry(user, mall, capacity)
                        elif menu_choice == "2":
                            vehicle_exit(user, mall)
                        elif menu_choice == "3":
                            parkingHistory(user)
                        elif menu_choice == "4":
                            feePayment(user)
                        elif menu_choice == "5":
                            break
                        else:
                            print("Invalid option.")
            
            elif role == "admin":
                if assigned_mall == "":
                    print("No mall assigned to this admin.")
                else:
                    # Set capacity based on mall
                    if assigned_mall == "Gateway":
                        capacity = 250
                    elif assigned_mall == "Pavilion":
                        capacity = 180
                    else:
                        capacity = 150
                    
                    while True:
                        print(f"---Admin Menu - {assigned_mall}---")
                        print("1 - View Vehicles Currently Parked")
                        print("2 - Monitor Parking Capacity")
                        print("3 - View Daily Parking Statistics")
                        print("4 - Logout")
                        
                        menu_choice = input("\nChoice: ")
                        
                        #admin menu ---> this adds to the functionality of the admin menu
                        if menu_choice == "1":
                            print(f"\nVehicles currently parked at {assigned_mall}:")
                            count = 0
                            try:
                                file = open("parking.txt", "r")
                                for line in file:
                                    data = line.strip().split(",")
                                    if len(data) >= 4 and data[1] == assigned_mall and data[3] == "0":
                                        print(f"User: {data[0]} | Entry: {time.ctime(int(data[2]))}")
                                        count += 1
                                file.close()
                            except:
                                pass
                            if count == 0:
                                print("No vehicles currently parked.")
                        
                        elif menu_choice == "2":
                            current = count_current_vehicles(assigned_mall)
                            print(f"\nCurrent vehicles: {current}/{capacity}")
                            print(f"Available spaces: {capacity - current}")
                        
                        elif menu_choice == "3":
                            today_start = int(time.time() - (time.time() % 86400))
                            total_today = 0
                            try:
                                file = open("parking.txt", "r")
                                for line in file:
                                    data = line.strip().split(",")
                                    if len(data) >= 3 and data[1] == assigned_mall:
                                        if int(data[2]) >= today_start:
                                            total_today += 1
                                file.close()
                                print(f"\nVehicles entered today: {total_today}")
                            except:
                                print("Unable to fetch statistics.")
                        
                        elif menu_choice == "4":
                            break
                        else:
                            print("Invalid option.")

                        #and finally the owner report(called when the function is mentioned under option 1) and menu
            elif role == "owner":
                while True:
                    print("Owner Menu")
                    print("1 - Generate Mall Reports")
                    print("2 - Logout")
                    
                    menu_choice = input("\nChoice: ")
                    
                    if menu_choice == "1":
                        owner_report()
                    elif menu_choice == "2":
                        break
                    else:
                        print("Invalid option.")
        
        elif choice == "3":
            print("Thank you for using the Parking Management System!")
            break
        
        else:
            print("Invalid choice. Please try again.")

if __name__ == "__main__":
    parkingSystem()